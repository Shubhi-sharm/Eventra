import React from 'react'
import { useParams, Link } from 'react-router-dom'
import {
  ArrowLeft,
  Star,
  Briefcase,
  GraduationCap,
  Clock,
  Award,
  User,
  CheckCircle2,
  Info,
} from 'lucide-react'
import { mentors } from '../data/mentors'
import { useApp } from '../context/AppContext'

export default function MentorDetails() {
  const { id } = useParams()
  const { requestMentorship, getMentorshipRequestStatus } = useApp()
  const mentor = mentors.find((m) => m.id === id)

  if (!mentor) {
    return (
      <div className="page-container">
        <p>Mentor not found.</p>
        <Link to="/mentors" className="btn btn-primary">Back to Mentors</Link>
      </div>
    )
  }

  const status = getMentorshipRequestStatus(mentor.id)

  return (
    <div className="page-container">
      <Link to="/mentors" className="back-link">
        <ArrowLeft size={16} /> Back to Mentors
      </Link>

      <div className="mentor-hero">
        <div className="mentor-hero-avatar">{mentor.avatar}</div>
        <div className="mentor-hero-info">
          <h1 className="mentor-hero-name">{mentor.name}</h1>
          <p className="mentor-hero-title">{mentor.title} @ {mentor.company}</p>
          <div className="mentor-hero-stats">
            <span><Star size={16} fill="var(--warning)" color="var(--warning)" /> {mentor.rating} Rating</span>
            <span><User size={16} /> {mentor.studentsMentored} Students Mentored</span>
          </div>
        </div>
        <div className="mentor-hero-action">
          {status === 'pending' ? (
            <span className="badge badge-amber">Request Pending</span>
          ) : status === 'accepted' ? (
            <span className="badge badge-green"><CheckCircle2 size={14} /> Connected</span>
          ) : (
            <button className="btn btn-primary" onClick={() => requestMentorship(mentor.id)}>
              Request Mentorship
            </button>
          )}
        </div>
      </div>

      <div className="demo-banner" style={{ marginTop: '20px' }}>
        <Info size={18} />
        <span>This is a <strong>demo</strong> — mentorship requests are stored locally and no real notification is sent.</span>
      </div>

      <div className="grid grid-2" style={{ marginTop: '24px' }}>
        <div className="card details-section">
          <h3 className="section-title"><GraduationCap size={20} className="text-violet" /> Qualifications</h3>
          <div className="info-row">
            <span className="info-label">Highest Qualification</span>
            <span className="info-value">{mentor.qualification}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Education</span>
            <span className="info-value">{mentor.education}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Specialization</span>
            <span className="info-value">{mentor.specialization}</span>
          </div>
        </div>

        <div className="card details-section">
          <h3 className="section-title"><Briefcase size={20} className="text-violet" /> Experience</h3>
          <p>{mentor.experience}</p>
          <h4 style={{ marginTop: '16px', marginBottom: '8px' }}>Areas of Expertise</h4>
          <div className="tech-tags">
            {mentor.expertise.map((exp) => (
              <span key={exp} className="badge badge-violet">{exp}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: '20px' }}>
        <div className="card details-section">
          <h3 className="section-title"><Award size={20} className="text-violet" /> Bio</h3>
          <p>{mentor.bio}</p>
          <h4 style={{ marginTop: '16px', marginBottom: '8px' }}>Mentoring Interests</h4>
          <div className="tech-tags">
            {mentor.interests.map((i) => (
              <span key={i} className="badge badge-blue">{i}</span>
            ))}
          </div>
        </div>

        <div className="card details-section">
          <h3 className="section-title"><Clock size={20} className="text-violet" /> Availability</h3>
          <p>{mentor.availability}</p>
        </div>
      </div>
    </div>
  )
}
