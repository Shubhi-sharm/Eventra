import React, { useState, useMemo } from 'react'
import { Search } from 'lucide-react'
import CommunityCard from '../components/CommunityCard'
import EmptyState from '../components/EmptyState'
import { communities, communityCategories } from '../data/communities'

export default function AllCommunities() {
  const [search, setSearch] = useState('')
  const [category, setCategory] = useState('All')

  const filtered = useMemo(() => {
    return communities.filter((c) => {
      const matchesSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.description.toLowerCase().includes(search.toLowerCase())
      const matchesCategory = category === 'All' || c.category === category
      return matchesSearch && matchesCategory
    })
  }, [search, category])

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">All Communities</h1>
          <p className="page-subtitle">Discover and join tech communities that match your interests</p>
        </div>
      </div>

      <div className="filter-bar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search communities..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <div className="filter-chips">
          {communityCategories.map((cat) => (
            <button
              key={cat}
              className={`chip ${category === cat ? 'chip-active' : ''}`}
              onClick={() => setCategory(cat)}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {filtered.length > 0 ? (
        <div className="grid grid-3">
          {filtered.map((c) => (
            <CommunityCard key={c.id} community={c} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Search}
          title="No communities found"
          description="Try adjusting your search or filter to find communities."
        />
      )}
    </div>
  )
}
