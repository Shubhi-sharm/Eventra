import React, { useState } from 'react'
import { Settings as SettingsIcon, Bell, Moon, Globe, Save, CheckCircle2, Info } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Settings() {
  const { user, updateProfile } = useApp()
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    eventReminders: true,
    communityUpdates: true,
    mentorshipAlerts: true,
    darkMode: false,
    language: 'English',
  })
  const [saved, setSaved] = useState(false)

  const toggle = (key) => {
    setSettings((s) => ({ ...s, [key]: !s[key] }))
  }

  const handleSave = () => {
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Settings</h1>
          <p className="page-subtitle">Manage your preferences (demo)</p>
        </div>
      </div>

      <div className="demo-banner">
        <Info size={18} />
        <span>Settings are for demonstration only and stored locally. No real backend integration.</span>
      </div>

      <div className="settings-grid">
        <div className="card details-section">
          <h3 className="section-title"><Bell size={20} className="text-violet" /> Notifications</h3>
          <div className="setting-row">
            <div>
              <div className="setting-label">Email Notifications</div>
              <div className="setting-desc">Receive updates via email</div>
            </div>
            <button className={`toggle ${settings.emailNotifications ? 'active' : ''}`} onClick={() => toggle('emailNotifications')}>
              <span className="toggle-knob" />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <div className="setting-label">Event Reminders</div>
              <div className="setting-desc">Get reminded before events</div>
            </div>
            <button className={`toggle ${settings.eventReminders ? 'active' : ''}`} onClick={() => toggle('eventReminders')}>
              <span className="toggle-knob" />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <div className="setting-label">Community Updates</div>
              <div className="setting-desc">Updates from joined communities</div>
            </div>
            <button className={`toggle ${settings.communityUpdates ? 'active' : ''}`} onClick={() => toggle('communityUpdates')}>
              <span className="toggle-knob" />
            </button>
          </div>
          <div className="setting-row">
            <div>
              <div className="setting-label">Mentorship Alerts</div>
              <div className="setting-desc">Alerts for mentorship requests</div>
            </div>
            <button className={`toggle ${settings.mentorshipAlerts ? 'active' : ''}`} onClick={() => toggle('mentorshipAlerts')}>
              <span className="toggle-knob" />
            </button>
          </div>
        </div>

        <div className="card details-section">
          <h3 className="section-title"><Moon size={20} className="text-violet" /> Appearance</h3>
          <div className="setting-row">
            <div>
              <div className="setting-label">Dark Mode</div>
              <div className="setting-desc">Coming soon — demo only</div>
            </div>
            <button className={`toggle ${settings.darkMode ? 'active' : ''}`} onClick={() => toggle('darkMode')}>
              <span className="toggle-knob" />
            </button>
          </div>
          <div className="form-group" style={{ marginTop: '16px' }}>
            <label className="form-label"><Globe size={14} /> Language</label>
            <select className="form-select" value={settings.language} onChange={(e) => setSettings({ ...settings, language: e.target.value })}>
              <option value="English">English</option>
              <option value="Spanish">Spanish</option>
              <option value="French">French</option>
              <option value="Hindi">Hindi</option>
            </select>
          </div>
        </div>

        <div className="card details-section">
          <h3 className="section-title"><SettingsIcon size={20} className="text-violet" /> Account</h3>
          <div className="info-row">
            <span className="info-label">Name</span>
            <span className="info-value">{user?.fullName}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Email</span>
            <span className="info-value">{user?.email}</span>
          </div>
          <div className="info-row">
            <span className="info-label">Role</span>
            <span className="info-value">{user?.role?.charAt(0).toUpperCase() + user?.role?.slice(1)}</span>
          </div>
          <button className="btn btn-primary" style={{ marginTop: '16px' }} onClick={handleSave}>
            {saved ? <><CheckCircle2 size={16} /> Saved!</> : <><Save size={16} /> Save Preferences</>}
          </button>
        </div>
      </div>
    </div>
  )
}
