import React, { useState, useMemo } from 'react'
import { Search } from 'lucide-react'
import MentorCard from '../components/MentorCard'
import EmptyState from '../components/EmptyState'
import { mentors, mentorExpertiseList } from '../data/mentors'

export default function Mentors() {
  const [search, setSearch] = useState('')
  const [expertise, setExpertise] = useState('All')

  const filtered = useMemo(() => {
    return mentors.filter((m) => {
      const matchesSearch = m.name.toLowerCase().includes(search.toLowerCase()) ||
        m.title.toLowerCase().includes(search.toLowerCase()) ||
        m.company.toLowerCase().includes(search.toLowerCase())
      const matchesExpertise = expertise === 'All' || m.expertise.includes(expertise)
      return matchesSearch && matchesExpertise
    })
  }, [search, expertise])

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Mentors</h1>
          <p className="page-subtitle">Connect with experienced mentors in your field</p>
        </div>
      </div>

      <div className="filter-bar">
        <div className="search-box">
          <Search size={18} />
          <input
            type="text"
            placeholder="Search mentors by name, title, or company..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
        <select
          className="form-select filter-select"
          value={expertise}
          onChange={(e) => setExpertise(e.target.value)}
        >
          {mentorExpertiseList.map((exp) => (
            <option key={exp} value={exp}>{exp === 'All' ? 'All Expertise' : exp}</option>
          ))}
        </select>
      </div>

      {filtered.length > 0 ? (
        <div className="grid grid-2">
          {filtered.map((m) => (
            <MentorCard key={m.id} mentor={m} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Search}
          title="No mentors found"
          description="Try adjusting your search or expertise filter."
        />
      )}
    </div>
  )
}
