import React, { useState } from 'react'
import { User, Mail, Phone, Building2, BookOpen, Save, CheckCircle2 } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Profile() {
  const { user, updateProfile } = useApp()
  const [form, setForm] = useState({
    fullName: user?.fullName || '',
    email: user?.email || '',
    phone: user?.phone || '',
    college: user?.college || '',
    branch: user?.branch || '',
    academicYear: user?.academicYear || '',
  })
  const [saved, setSaved] = useState(false)

  const handleSave = () => {
    updateProfile(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">My Profile</h1>
          <p className="page-subtitle">Manage your personal information</p>
        </div>
      </div>

      <div className="profile-layout">
        <div className="card profile-sidebar">
          <div className="profile-avatar-large">{user?.fullName?.charAt(0).toUpperCase() || 'U'}</div>
          <h2 className="profile-name">{user?.fullName || 'User'}</h2>
          <p className="profile-role-label">{user?.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'User'}</p>
          {user?.role === 'participant' && user?.technicalSkills && (
            <div className="profile-skills">
              {user.technicalSkills.split(',').map((s, i) => (
                <span key={i} className="badge badge-violet">{s.trim()}</span>
              ))}
            </div>
          )}
          {user?.role === 'mentor' && user?.specialization && (
            <p className="text-muted" style={{ marginTop: '12px' }}>{user.specialization}</p>
          )}
        </div>

        <div className="card profile-form-card">
          <h3 className="section-title"><User size={20} className="text-violet" /> Personal Information</h3>
          <div className="grid grid-2">
            <div className="form-group">
              <label className="form-label"><User size={14} /> Full Name</label>
              <input className="form-input" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label"><Mail size={14} /> Email</label>
              <input className="form-input" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label"><Phone size={14} /> Phone</label>
              <input className="form-input" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label"><Building2 size={14} /> College / University</label>
              <input className="form-input" value={form.college} onChange={(e) => setForm({ ...form, college: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label"><BookOpen size={14} /> Branch</label>
              <input className="form-input" value={form.branch} onChange={(e) => setForm({ ...form, branch: e.target.value })} />
            </div>
            <div className="form-group">
              <label className="form-label">Academic Year</label>
              <select className="form-select" value={form.academicYear} onChange={(e) => setForm({ ...form, academicYear: e.target.value })}>
                <option value="">Select...</option>
                {['1st Year', '2nd Year', '3rd Year', '4th Year', 'Graduate', 'Postgraduate'].map((y) => (
                  <option key={y} value={y}>{y}</option>
                ))}
              </select>
            </div>
          </div>
          <button className="btn btn-primary" onClick={handleSave}>
            {saved ? <><CheckCircle2 size={16} /> Saved!</> : <><Save size={16} /> Save Changes</>}
          </button>
        </div>
      </div>
    </div>
  )
}
