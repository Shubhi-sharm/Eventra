import React, { useState, useMemo } from 'react'
import { Link } from 'react-router-dom'
import {
  Sparkles,
  Plus,
  Users,
  Lightbulb,
  Code2,
  CheckCircle2,
  Info,
  Github,
  Linkedin,
  ExternalLink,
  BriefcaseBusiness,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import TeamMatchCard from '../components/TeamMatchCard'
import Modal from '../components/Modal'
import EmptyState from '../components/EmptyState'
import { potentialTeammates, calculateCompatibility } from '../data/teamMatches'
import { TEAM_ROLES } from '../data/constants'

export default function TeamFormation() {
  const { teams, createTeam, invitations, sendInvitation, acceptInvitation, declineInvitation } = useApp()
  const [showCreateModal, setShowCreateModal] = useState(false)
  const [teamForm, setTeamForm] = useState({ name: '', projectIdea: '', technologies: '', roles: [] })

  const [prefs, setPrefs] = useState({ technologies: [], interests: [], roles: [] })
  const [techInput, setTechInput] = useState('')
  const [interestInput, setInterestInput] = useState('')
  const [profileLinks, setProfileLinks] = useState({ github: '', linkedin: '', portfolio: '' })
  const [matchCriteria, setMatchCriteria] = useState({ skills: true, projects: true, experience: true, roles: true, availability: true })
  const [profileSaved, setProfileSaved] = useState(false)

  const myInvitations = invitations.filter((i) => i.status === 'pending')

  const matches = useMemo(() => {
    return potentialTeammates.map((t) => ({
      ...t,
      score: calculateCompatibility(prefs, t),
    })).sort((a, b) => b.score - a.score)
  }, [prefs])

  const addTech = () => {
    if (techInput.trim()) {
      setPrefs((p) => ({ ...p, technologies: [...p.technologies, techInput.trim()] }))
      setTechInput('')
    }
  }
  const addInterest = () => {
    if (interestInput.trim()) {
      setPrefs((p) => ({ ...p, interests: [...p.interests, interestInput.trim()] }))
      setInterestInput('')
    }
  }
  const toggleRole = (role) => {
    setPrefs((p) => ({
      ...p,
      roles: p.roles.includes(role) ? p.roles.filter((r) => r !== role) : [...p.roles, role],
    }))
  }

  const handleCreateTeam = () => {
    if (!teamForm.name.trim()) return
    createTeam({
      name: teamForm.name,
      projectIdea: teamForm.projectIdea,
      technologies: teamForm.technologies.split(',').map((t) => t.trim()).filter(Boolean),
      roles: teamForm.roles,
    })
    setTeamForm({ name: '', projectIdea: '', technologies: '', roles: [] })
    setShowCreateModal(false)
  }

  const getInviteStatus = (teammateId) => {
    const inv = invitations.find((i) => i.teammateId === teammateId)
    return inv ? inv.status : null
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title"><Sparkles className="inline" /> AI Team Formation</h1>
          <p className="page-subtitle">Find your perfect teammates using AI-powered matching (Demo)</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowCreateModal(true)}>
          <Plus size={16} /> Create Team
        </button>
      </div>

      <div className="demo-banner">
        <Info size={18} />
        <span>This is a <strong>frontend demo</strong>. Compatibility scores are calculated from sample skill and interest overlap — not real AI predictions.</span>
      </div>

      <div className="card profile-criteria-card" style={{ marginBottom: '24px' }}>
        <div className="criteria-heading">
          <div>
            <h3 className="section-title"><Github size={20} className="text-violet" /> LinkedIn & GitHub Match Criteria</h3>
            <p className="text-muted">Add your profiles and choose which signals should influence teammate recommendations.</p>
          </div>
          <span className="badge badge-violet">PROFILE-BASED</span>
        </div>
        <div className="profile-link-grid">
          <div className="form-group">
            <label className="form-label"><Github size={15} /> GitHub profile URL</label>
            <input className="form-input" type="url" placeholder="https://github.com/yourusername" value={profileLinks.github} onChange={(e) => { setProfileLinks(p => ({ ...p, github: e.target.value })); setProfileSaved(false) }} />
            <p className="form-hint">Use project repositories, languages and relevant contributions when available.</p>
          </div>
          <div className="form-group">
            <label className="form-label"><Linkedin size={15} /> LinkedIn profile URL</label>
            <input className="form-input" type="url" placeholder="https://linkedin.com/in/yourname" value={profileLinks.linkedin} onChange={(e) => { setProfileLinks(p => ({ ...p, linkedin: e.target.value })); setProfileSaved(false) }} />
            <p className="form-hint">Use declared skills, education, experience and career interests with permission.</p>
          </div>
          <div className="form-group">
            <label className="form-label"><ExternalLink size={15} /> Portfolio / other tech profile</label>
            <input className="form-input" type="url" placeholder="https://your-portfolio.com" value={profileLinks.portfolio} onChange={(e) => { setProfileLinks(p => ({ ...p, portfolio: e.target.value })); setProfileSaved(false) }} />
          </div>
        </div>
        <div className="criteria-options">
          <div className="criteria-options-title"><BriefcaseBusiness size={16} /> Matching signals</div>
          {[
            ['skills', 'Complementary skills', 'Cover the technologies required by the project'],
            ['projects', 'Relevant projects', 'Consider related repositories and portfolio work'],
            ['experience', 'Experience & education', 'Use relevant experience and learning background'],
            ['roles', 'Role coverage', 'Avoid gaps in required team responsibilities'],
            ['availability', 'Availability & interests', 'Prefer compatible schedules and shared goals'],
          ].map(([key, title, description]) => (
            <label className="criteria-option" key={key}>
              <input type="checkbox" checked={matchCriteria[key]} onChange={(e) => setMatchCriteria(p => ({ ...p, [key]: e.target.checked }))} />
              <span><strong>{title}</strong><small>{description}</small></span>
            </label>
          ))}
        </div>
        <div className="criteria-footer">
          <p className="form-hint">Privacy note: profile URLs are only saved in this page's demo state. This prototype does not scrape LinkedIn or fetch GitHub API data.</p>
          <button className="btn btn-primary" onClick={() => { localStorage.setItem('eventra_team_profile_links', JSON.stringify(profileLinks)); localStorage.setItem('eventra_team_match_criteria', JSON.stringify(matchCriteria)); setProfileSaved(true) }}>{profileSaved ? <CheckCircle2 size={16} /> : <Sparkles size={16} />}{profileSaved ? 'Criteria saved' : 'Save matching criteria'}</button>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginBottom: '24px' }}>
        <div className="card details-section">
          <h3 className="section-title"><Lightbulb size={20} className="text-violet" /> Your Team Preferences</h3>
          <div className="form-group">
            <label className="form-label">Preferred Technologies</label>
            <div className="tag-input">
              <input
                type="text"
                className="form-input"
                placeholder="e.g. React, Python"
                value={techInput}
                onChange={(e) => setTechInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addTech())}
              />
              <button type="button" className="btn btn-primary btn-sm" onClick={addTech}>Add</button>
            </div>
            <div className="tag-list">
              {prefs.technologies.map((t) => (
                <span key={t} className="badge badge-violet">
                  {t} <button onClick={() => setPrefs((p) => ({ ...p, technologies: p.technologies.filter((x) => x !== t) }))}>×</button>
                </span>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Interests</label>
            <div className="tag-input">
              <input
                type="text"
                className="form-input"
                placeholder="e.g. AI, Web Dev"
                value={interestInput}
                onChange={(e) => setInterestInput(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addInterest())}
              />
              <button type="button" className="btn btn-primary btn-sm" onClick={addInterest}>Add</button>
            </div>
            <div className="tag-list">
              {prefs.interests.map((i) => (
                <span key={i} className="badge badge-blue">
                  {i} <button onClick={() => setPrefs((p) => ({ ...p, interests: p.interests.filter((x) => x !== i) }))}>×</button>
                </span>
              ))}
            </div>
          </div>
          <div className="form-group">
            <label className="form-label">Preferred Roles</label>
            <div className="multiselect">
              {TEAM_ROLES.map((role) => (
                <button
                  key={role}
                  type="button"
                  className={`chip ${prefs.roles.includes(role) ? 'chip-active' : ''}`}
                  onClick={() => toggleRole(role)}
                >
                  {role}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="card details-section">
          <h3 className="section-title"><Users size={20} className="text-violet" /> Your Teams</h3>
          {teams.length > 0 ? (
            <div className="team-list">
              {teams.map((team) => (
                <div key={team.id} className="team-item">
                  <div className="team-info">
                    <h4>{team.name}</h4>
                    {team.projectIdea && <p><strong>Idea:</strong> {team.projectIdea}</p>}
                    {team.technologies?.length > 0 && (
                      <div className="tech-tags">
                        {team.technologies.map((t) => (
                          <span key={t} className="badge badge-violet">{t}</span>
                        ))}
                      </div>
                    )}
                  </div>
                  <span className="badge badge-green"><CheckCircle2 size={12} /> Created</span>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={Users}
              title="No teams yet"
              description="Create your first team to get started."
            />
          )}

          {myInvitations.length > 0 && (
            <div style={{ marginTop: '24px' }}>
              <h4>Pending Invitations</h4>
              {myInvitations.map((inv) => {
                const teammate = potentialTeammates.find((t) => t.id === inv.teammateId)
                return (
                  <div key={inv.id} className="invitation-item">
                    <div className="invitation-avatar">{teammate?.avatar}</div>
                    <div>
                      <div className="invitation-name">{teammate?.name}</div>
                      <div className="text-muted">Wants to join your team</div>
                    </div>
                    <div className="invitation-actions">
                      <button className="btn btn-primary btn-sm" onClick={() => acceptInvitation(inv.id)}>Accept</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => declineInvitation(inv.id)}>Decline</button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>

      <div className="card details-section">
        <h3 className="section-title"><Sparkles size={20} className="text-violet" /> Potential Teammates (Demo Matches)</h3>
        <p className="text-muted" style={{ marginBottom: '16px' }}>Matches are sorted by compatibility score based on your preferences above.</p>
        <div className="grid grid-2">
          {matches.map((t) => (
            <TeamMatchCard
              key={t.id}
              teammate={t}
              score={t.score}
              inviteStatus={getInviteStatus(t.id)}
              onInvite={() => sendInvitation({ teammateId: t.id, teamId: teams[0]?.id })}
            />
          ))}
        </div>
      </div>

      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create a New Team"
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setShowCreateModal(false)}>Cancel</button>
            <button className="btn btn-primary" onClick={handleCreateTeam}>Create Team</button>
          </>
        }
      >
        <div className="form-group">
          <label className="form-label">Team Name <span className="required">*</span></label>
          <input
            type="text"
            className="form-input"
            placeholder="e.g. Neural Nomads"
            value={teamForm.name}
            onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })}
          />
        </div>
        <div className="form-group">
          <label className="form-label">Project Idea</label>
          <textarea
            className="form-textarea"
            placeholder="Describe your project idea..."
            value={teamForm.projectIdea}
            onChange={(e) => setTeamForm({ ...teamForm, projectIdea: e.target.value })}
          />
        </div>
        <div className="form-group">
          <label className="form-label">Preferred Technologies</label>
          <input
            type="text"
            className="form-input"
            placeholder="Comma-separated: React, Python, Node.js"
            value={teamForm.technologies}
            onChange={(e) => setTeamForm({ ...teamForm, technologies: e.target.value })}
          />
        </div>
        <div className="form-group">
          <label className="form-label">Roles Needed</label>
          <div className="multiselect">
            {TEAM_ROLES.map((role) => (
              <button
                key={role}
                type="button"
                className={`chip ${teamForm.roles.includes(role) ? 'chip-active' : ''}`}
                onClick={() => setTeamForm((f) => ({
                  ...f,
                  roles: f.roles.includes(role) ? f.roles.filter((r) => r !== role) : [...f.roles, role],
                }))}
              >
                {role}
              </button>
            ))}
          </div>
        </div>
      </Modal>
    </div>
  )
}
