import React from 'react'
import { Link } from 'react-router-dom'
import {
  Users,
  Calendar,
  Award,
  Sparkles,
  ArrowRight,
  Calendar as CalendarIcon,
  Globe,
  Activity,
  Plus,
  UserPlus,
  Rocket,
} from 'lucide-react'
import { useApp } from '../context/AppContext'
import StatCard from '../components/StatCard'
import CommunityCard from '../components/CommunityCard'
import { communities } from '../data/communities'
import { events } from '../data/events'
import { recentActivities } from '../data/activities'
import { ROLES } from '../data/constants'

const activityIconMap = {
  Users: Users,
  Calendar: Calendar,
  GraduationCap: Users,
  Bell: Sparkles,
}

export default function Dashboard() {
  const { user, joinedCommunities, registrations, teams } = useApp()

  const upcomingEvents = events.slice(0, 3)
  const joinedCommunityObjects = communities.filter((c) => joinedCommunities.includes(c.id))
  const recommendedCommunities = communities.filter((c) => !joinedCommunities.includes(c.id)).slice(0, 3)
  const registeredEvents = events.filter((e) => registrations.includes(e.id))

  const quickActions = [
    { label: 'Browse Communities', icon: Globe, to: '/communities', color: 'violet' },
    { label: 'Find Events', icon: Calendar, to: '/events', color: 'blue' },
    { label: 'Form a Team', icon: Rocket, to: '/team-formation', color: 'green' },
    { label: 'Find a Mentor', icon: UserPlus, to: '/mentors', color: 'amber' },
  ]

  const roleSpecificActions = {
    [ROLES.MENTOR]: [{ label: 'My Mentee Requests', icon: UserPlus, to: '/mentors', color: 'blue' }],
    [ROLES.PARTICIPANT]: [{ label: 'Create Team', icon: Plus, to: '/team-formation', color: 'green' }],
    [ROLES.MEMBER]: [{ label: 'Explore Communities', icon: Globe, to: '/communities', color: 'violet' }],
  }

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Welcome back, {user?.fullName?.split(' ')[0] || 'there'}! 👋</h1>
          <p className="page-subtitle">Here's what's happening in your Eventra community today.</p>
        </div>
      </div>

      <div className="grid grid-4" style={{ marginBottom: '24px' }}>
        <StatCard icon={Users} label="Joined Communities" value={joinedCommunities.length} change="+2 this week" color="violet" />
        <StatCard icon={Calendar} label="Event Registrations" value={registrations.length} change="+1 this week" color="blue" />
        <StatCard icon={Award} label="Teams Created" value={teams.length} change="Active" color="green" />
        <StatCard icon={Sparkles} label="AI Matches" value="12" change="New matches" color="amber" />
      </div>

      <div className="grid grid-3" style={{ marginBottom: '24px' }}>
        {quickActions.map((action) => (
          <Link key={action.label} to={action.to} className="quick-action-card">
            <div className={`qa-icon qa-${action.color}`}>
              <action.icon size={22} />
            </div>
            <span>{action.label}</span>
            <ArrowRight size={16} className="qa-arrow" />
          </Link>
        ))}
      </div>

      <div className="grid grid-2">
        <div className="card dashboard-section">
          <div className="dashboard-section-header">
            <h3 className="section-title"><CalendarIcon size={20} className="text-violet" /> Upcoming Events</h3>
            <Link to="/events" className="btn btn-ghost btn-sm">View all</Link>
          </div>
          <div className="event-list">
            {upcomingEvents.map((event) => (
              <Link to={`/events/${event.id}`} key={event.id} className="event-list-item">
                <div className="event-list-date">
                  <span className="event-day">{new Date(event.date).getDate()}</span>
                  <span className="event-month">{new Date(event.date).toLocaleString('en-US', { month: 'short' })}</span>
                </div>
                <div className="event-list-info">
                  <h4>{event.title}</h4>
                  <p>{event.organizer} · {event.venue}</p>
                </div>
                <span className="badge badge-violet">{event.category}</span>
              </Link>
            ))}
          </div>
        </div>

        <div className="card dashboard-section">
          <div className="dashboard-section-header">
            <h3 className="section-title"><Activity size={20} className="text-violet" /> Recent Activity</h3>
          </div>
          <div className="activity-list">
            {recentActivities.map((a) => {
              const Icon = activityIconMap[a.icon] || Activity
              return (
                <div key={a.id} className="activity-item">
                  <div className="activity-icon">
                    <Icon size={16} />
                  </div>
                  <div className="activity-content">
                    <p>{a.message}</p>
                    <span className="activity-time">{a.time}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      {joinedCommunityObjects.length > 0 && (
        <div className="dashboard-section" style={{ marginTop: '24px' }}>
          <div className="dashboard-section-header">
            <h3 className="section-title"><Globe size={20} className="text-violet" /> Your Communities</h3>
            <Link to="/my-communities" className="btn btn-ghost btn-sm">View all</Link>
          </div>
          <div className="grid grid-3">
            {joinedCommunityObjects.slice(0, 3).map((c) => (
              <CommunityCard key={c.id} community={c} />
            ))}
          </div>
        </div>
      )}

      <div className="dashboard-section" style={{ marginTop: '24px' }}>
        <div className="dashboard-section-header">
          <h3 className="section-title"><Sparkles size={20} className="text-violet" /> Recommended Communities</h3>
          <Link to="/communities" className="btn btn-ghost btn-sm">Explore all</Link>
        </div>
        <div className="grid grid-3">
          {recommendedCommunities.map((c) => (
            <CommunityCard key={c.id} community={c} />
          ))}
        </div>
      </div>

      {registeredEvents.length > 0 && (
        <div className="dashboard-section" style={{ marginTop: '24px' }}>
          <div className="dashboard-section-header">
            <h3 className="section-title"><Calendar size={20} className="text-violet" /> Your Registered Events</h3>
            <Link to="/my-registrations" className="btn btn-ghost btn-sm">View all</Link>
          </div>
          <div className="event-list">
            {registeredEvents.slice(0, 3).map((event) => (
              <Link to={`/events/${event.id}`} key={event.id} className="event-list-item">
                <div className="event-list-date">
                  <span className="event-day">{new Date(event.date).getDate()}</span>
                  <span className="event-month">{new Date(event.date).toLocaleString('en-US', { month: 'short' })}</span>
                </div>
                <div className="event-list-info">
                  <h4>{event.title}</h4>
                  <p>{event.organizer} · {event.venue}</p>
                </div>
                <span className="badge badge-green">Registered</span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
