import React, { useState, useEffect } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Users, GraduationCap, Rocket } from 'lucide-react'
import RegistrationForm from '../components/RegistrationForm'
import { ROLES } from '../data/constants'

const roleConfig = {
  [ROLES.MEMBER]: { label: 'Member', icon: Users, color: 'violet' },
  [ROLES.MENTOR]: { label: 'Mentor', icon: GraduationCap, color: 'blue' },
  [ROLES.PARTICIPANT]: { label: 'Participant', icon: Rocket, color: 'green' },
}

export default function Register() {
  const [searchParams, setSearchParams] = useSearchParams()
  const urlRole = searchParams.get('role')
  const [role, setRole] = useState(urlRole && Object.values(ROLES).includes(urlRole) ? urlRole : ROLES.PARTICIPANT)

  useEffect(() => {
    if (urlRole && Object.values(ROLES).includes(urlRole)) {
      setRole(urlRole)
    }
  }, [urlRole])

  const handleRoleSelect = (r) => {
    setRole(r)
    setSearchParams({ role: r })
  }

  return (
    <div className="auth-page">
      <div className="auth-container auth-container-wide">
        <div className="auth-brand">
          <Link to="/" className="landing-logo">
            <span className="logo-mark">E</span>
            <span className="logo-text">Eventra</span>
          </Link>
          <h2>Join Eventra</h2>
          <p>Create your account and start connecting with tech communities.</p>
          <div className="role-selector">
            {Object.entries(roleConfig).map(([key, cfg]) => (
              <button
                key={key}
                className={`role-tab ${role === key ? 'role-tab-active' : ''}`}
                onClick={() => handleRoleSelect(key)}
              >
                <cfg.icon size={18} /> {cfg.label}
              </button>
            ))}
          </div>
        </div>
        <div className="auth-form-wrapper">
          <RegistrationForm key={role} role={role} />
          <p className="auth-footer">
            Already have an account? <Link to="/login">Login here</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
