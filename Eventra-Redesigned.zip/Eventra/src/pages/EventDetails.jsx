import React from 'react'
import { useParams, Link } from 'react-router-dom'
import {
  Calendar,
  MapPin,
  Users,
  Clock,
  ArrowLeft,
  CheckCircle2,
  AlertCircle,
} from 'lucide-react'
import { events } from '../data/events'
import { useApp } from '../context/AppContext'

export default function EventDetails() {
  const { id } = useParams()
  const { isEventRegistered, registerForEvent, unregisterFromEvent } = useApp()
  const event = events.find((e) => e.id === id)

  if (!event) {
    return (
      <div className="page-container">
        <p>Event not found.</p>
        <Link to="/events" className="btn btn-primary">Back to Events</Link>
      </div>
    )
  }

  const registered = isEventRegistered(event.id)
  const isFull = event.participants >= event.maxParticipants
  const spotsLeft = event.maxParticipants - event.participants

  return (
    <div className="page-container">
      <Link to="/events" className="back-link">
        <ArrowLeft size={16} /> Back to Events
      </Link>

      <div className="event-details-hero">
        <div className="event-hero-badges">
          <span className="badge badge-violet">{event.category}</span>
          {event.online ? (
            <span className="badge badge-green">Online</span>
          ) : (
            <span className="badge badge-slate">In-Person</span>
          )}
        </div>
        <h1 className="event-hero-title">{event.title}</h1>
        <p className="event-hero-organizer">Organized by <strong>{event.organizer}</strong></p>
        <p className="event-hero-desc">{event.description}</p>

        <div className="event-hero-meta">
          <div className="meta-item">
            <Calendar size={20} className="text-violet" />
            <div>
              <div className="meta-label">Event Date</div>
              <div className="meta-value">{new Date(event.date).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })}</div>
            </div>
          </div>
          <div className="meta-item">
            <Clock size={20} className="text-violet" />
            <div>
              <div className="meta-label">Registration Deadline</div>
              <div className="meta-value">{new Date(event.deadline).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}</div>
            </div>
          </div>
          <div className="meta-item">
            <MapPin size={20} className="text-violet" />
            <div>
              <div className="meta-label">Venue</div>
              <div className="meta-value">{event.venue}</div>
            </div>
          </div>
          <div className="meta-item">
            <Users size={20} className="text-violet" />
            <div>
              <div className="meta-label">Participants</div>
              <div className="meta-value">{event.participants} / {event.maxParticipants} <span className="text-muted">({spotsLeft} spots left)</span></div>
            </div>
          </div>
        </div>

        <div className="event-hero-action">
          {registered ? (
            <button className="btn btn-danger" onClick={() => unregisterFromEvent(event.id)}>
              Unregister from Event
            </button>
          ) : (
            <button
              className="btn btn-primary"
              disabled={isFull}
              onClick={() => registerForEvent(event.id)}
            >
              {isFull ? 'Event is Full' : 'Register for Event'}
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: '24px' }}>
        <div className="card details-section">
          <h3 className="section-title">About this Event</h3>
          <p>{event.description}</p>
          <div className="event-tags" style={{ marginTop: '16px' }}>
            {event.tags.map((tag) => (
              <span key={tag} className="badge badge-slate">{tag}</span>
            ))}
          </div>
        </div>
        <div className="card details-section">
          <h3 className="section-title">Eligibility</h3>
          <p>{event.eligibility}</p>
          <div className="eligibility-notes" style={{ marginTop: '16px' }}>
            <div className="note-item"><CheckCircle2 size={16} className="text-success" /> Registration is free</div>
            <div className="note-item"><CheckCircle2 size={16} className="text-success" /> Certificate of participation</div>
            <div className="note-item"><AlertCircle size={16} className="text-violet" /> Demo registration only — no real confirmation email is sent.</div>
          </div>
        </div>
      </div>
    </div>
  )
}
