import React from 'react'
import { Link } from 'react-router-dom'
import { Calendar, ClipboardList, ArrowLeft } from 'lucide-react'
import EmptyState from '../components/EmptyState'
import { events } from '../data/events'
import { useApp } from '../context/AppContext'

export default function MyRegistrations() {
  const { registrations, unregisterFromEvent } = useApp()
  const myEvents = events.filter((e) => registrations.includes(e.id))

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">My Registrations</h1>
          <p className="page-subtitle">Events you've registered for</p>
        </div>
        <Link to="/events" className="btn btn-primary">
          <Calendar size={16} /> Browse Events
        </Link>
      </div>

      {myEvents.length > 0 ? (
        <div className="event-list">
          {myEvents.map((event) => (
            <div key={event.id} className="card event-list-item registration-item">
              <div className="event-list-date">
                <span className="event-day">{new Date(event.date).getDate()}</span>
                <span className="event-month">{new Date(event.date).toLocaleString('en-US', { month: 'short' })}</span>
              </div>
              <div className="event-list-info">
                <h4>{event.title}</h4>
                <p>{event.organizer} · {event.venue}</p>
                <span className="badge badge-green">Registered</span>
              </div>
              <div className="registration-actions">
                <Link to={`/events/${event.id}`} className="btn btn-secondary btn-sm">View Details</Link>
                <button className="btn btn-danger btn-sm" onClick={() => unregisterFromEvent(event.id)}>Unregister</button>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={ClipboardList}
          title="No registrations yet"
          description="Browse events and register for the ones you're interested in."
          action={<Link to="/events" className="btn btn-primary">Browse Events</Link>}
        />
      )}
    </div>
  )
}
