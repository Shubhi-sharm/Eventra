import React from 'react'
import { Link } from 'react-router-dom'
import { Users, GraduationCap, Rocket, ArrowRight, Sparkles } from 'lucide-react'
import { ROLES } from '../data/constants'

const roles = [
  {
    role: ROLES.MEMBER,
    title: 'Join as a Member',
    icon: Users,
    description: 'Be part of thriving tech communities, contribute to discussions, and grow alongside like-minded enthusiasts.',
    color: 'violet',
  },
  {
    role: ROLES.MENTOR,
    title: 'Join as a Mentor',
    icon: GraduationCap,
    description: 'Share your expertise, guide the next generation of innovators, and shape the future of technology.',
    color: 'blue',
  },
  {
    role: ROLES.PARTICIPANT,
    title: 'Join as a Participant',
    icon: Rocket,
    description: 'Compete in hackathons, attend workshops, and build amazing projects with AI-powered team formation.',
    color: 'green',
  },
]

export default function Landing() {
  return (
    <div className="landing-page">
      <nav className="landing-nav">
        <div className="landing-logo">
          <span className="logo-mark">E</span>
          <span className="logo-text">Eventra</span>
        </div>
        <div className="landing-nav-actions">
          <Link to="/login" className="btn btn-ghost">Login</Link>
          <Link to="/register" className="btn btn-primary">Get Started</Link>
        </div>
      </nav>

      <section className="landing-hero">
        <div className="hero-content">
          <div className="hero-badge">
            <Sparkles size={16} /> AI-Powered Tech Community Platform
          </div>
          <h1 className="hero-title">Welcome to Eventra</h1>
          <p className="hero-tagline">Connect. Collaborate. Create.</p>
          <p className="hero-description">
            Discover tech communities, learn from mentors, participate in events, and build your dream team.
          </p>
          <div className="hero-actions">
            <Link to="/register" className="btn btn-primary btn-lg">
              Get Started Free <ArrowRight size={18} />
            </Link>
            <Link to="/login" className="btn btn-secondary btn-lg">I have an account</Link>
          </div>
        </div>
        <div className="hero-visual">
          <div className="hero-card hero-card-1">
            <div className="hc-icon">🤖</div>
            <div className="hc-text">AI Team Formation</div>
          </div>
          <div className="hero-card hero-card-2">
            <div className="hc-icon">🏆</div>
            <div className="hc-text">Hackathons</div>
          </div>
          <div className="hero-card hero-card-3">
            <div className="hc-icon">👥</div>
            <div className="hc-text">Communities</div>
          </div>
          <div className="hero-card hero-card-4">
            <div className="hc-icon">🎓</div>
            <div className="hc-text">Mentorship</div>
          </div>
        </div>
      </section>

      <section className="landing-roles">
        <h2 className="roles-heading">Choose your path</h2>
        <p className="roles-subheading">Pick the role that suits you best and start your journey</p>
        <div className="roles-grid">
          {roles.map((r) => (
            <div key={r.role} className={`role-card role-card-${r.color}`}>
              <div className="role-icon">
                <r.icon size={36} />
              </div>
              <h3 className="role-title">{r.title}</h3>
              <p className="role-description">{r.description}</p>
              <Link to={`/register?role=${r.role}`} className="btn btn-primary btn-block">
                Get Started <ArrowRight size={16} />
              </Link>
            </div>
          ))}
        </div>
      </section>

      <footer className="landing-footer">
        <div className="landing-logo">
          <span className="logo-mark">E</span>
          <span className="logo-text">Eventra</span>
        </div>
        <p className="footer-text">© 2026 Eventra. Connect. Collaborate. Create.</p>
      </footer>
    </div>
  )
}
