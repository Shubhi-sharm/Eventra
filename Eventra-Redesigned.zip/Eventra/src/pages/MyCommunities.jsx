import React from 'react'
import { Link } from 'react-router-dom'
import { Globe, Users } from 'lucide-react'
import CommunityCard from '../components/CommunityCard'
import EmptyState from '../components/EmptyState'
import { communities } from '../data/communities'
import { useApp } from '../context/AppContext'

export default function MyCommunities() {
  const { joinedCommunities } = useApp()
  const myCommunities = communities.filter((c) => joinedCommunities.includes(c.id))

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">My Communities</h1>
          <p className="page-subtitle">Communities you've joined</p>
        </div>
        <Link to="/communities" className="btn btn-primary">
          <Globe size={16} /> Explore Communities
        </Link>
      </div>

      {myCommunities.length > 0 ? (
        <div className="grid grid-3">
          {myCommunities.map((c) => (
            <CommunityCard key={c.id} community={c} />
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Users}
          title="No communities joined yet"
          description="Explore communities and join the ones that match your interests."
          action={<Link to="/communities" className="btn btn-primary">Browse Communities</Link>}
        />
      )}
    </div>
  )
}
