import React from 'react'
import { Bell, Info, Calendar, Users, GraduationCap } from 'lucide-react'
import { useApp } from '../context/AppContext'
import EmptyState from '../components/EmptyState'

const typeIconMap = {
  info: Info,
  event: Calendar,
  community: Users,
  mentor: GraduationCap,
}

const typeBadgeMap = {
  info: 'badge-blue',
  event: 'badge-violet',
  community: 'badge-green',
  mentor: 'badge-amber',
}

export default function Notifications() {
  const { notifications, markNotificationRead, markAllNotificationsRead } = useApp()

  return (
    <div className="page-container">
      <div className="page-header">
        <div>
          <h1 className="page-title">Notifications</h1>
          <p className="page-subtitle">Stay updated with the latest from Eventra</p>
        </div>
        {notifications.some((n) => !n.read) && (
          <button className="btn btn-secondary btn-sm" onClick={markAllNotificationsRead}>
            Mark all as read
          </button>
        )}
      </div>

      {notifications.length > 0 ? (
        <div className="notification-list">
          {notifications.map((n) => {
            const Icon = typeIconMap[n.type] || Bell
            return (
              <div
                key={n.id}
                className={`card notification-item ${n.read ? '' : 'unread'}`}
                onClick={() => markNotificationRead(n.id)}
              >
                <div className={`notification-icon ${typeBadgeMap[n.type] || 'badge-slate'}`}>
                  <Icon size={20} />
                </div>
                <div className="notification-content">
                  <div className="notification-title">{n.title}</div>
                  <div className="notification-message">{n.message}</div>
                </div>
                <div className="notification-time">{n.time}</div>
                {!n.read && <div className="unread-dot" />}
              </div>
            )
          })}
        </div>
      ) : (
        <EmptyState
          icon={Bell}
          title="No notifications"
          description="You're all caught up! New notifications will appear here."
        />
      )}
    </div>
  )
}
