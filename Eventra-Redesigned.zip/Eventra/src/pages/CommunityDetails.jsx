import React from 'react'
import { useParams, Link } from 'react-router-dom'
import {
  Users,
  Calendar,
  Target,
  BookOpen,
  Shield,
  Wrench,
  ArrowLeft,
  CheckCircle2,
} from 'lucide-react'
import { communities } from '../data/communities'
import { events } from '../data/events'
import { useApp } from '../context/AppContext'

export default function CommunityDetails() {
  const { id } = useParams()
  const { isCommunityJoined, joinCommunity, leaveCommunity } = useApp()
  const community = communities.find((c) => c.id === id)

  if (!community) {
    return (
      <div className="page-container">
        <p>Community not found.</p>
        <Link to="/communities" className="btn btn-primary">Back to Communities</Link>
      </div>
    )
  }

  const joined = isCommunityJoined(community.id)
  const communityEvents = events.filter((e) => e.communityId === community.id)

  return (
    <div className="page-container">
      <Link to="/communities" className="back-link">
        <ArrowLeft size={16} /> Back to Communities
      </Link>

      <div className="community-hero">
        <div className="community-hero-logo">{community.logo}</div>
        <div className="community-hero-info">
          <h1 className="community-hero-name">{community.name}</h1>
          <span className="badge badge-violet">{community.category}</span>
          <p className="community-hero-desc">{community.description}</p>
          <div className="community-hero-meta">
            <span><Users size={16} /> {community.members.toLocaleString()} members</span>
            <span>Lead: {community.lead}</span>
            <span><Calendar size={16} /> {community.upcomingEvents} upcoming events</span>
          </div>
        </div>
        <div className="community-hero-action">
          {joined ? (
            <button className="btn btn-danger" onClick={() => leaveCommunity(community.id)}>
              Leave Community
            </button>
          ) : (
            <button className="btn btn-primary" onClick={() => joinCommunity(community.id)}>
              Join Community
            </button>
          )}
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: '24px' }}>
        <div className="card details-section">
          <h3 className="section-title"><Target size={20} className="text-violet" /> Mission</h3>
          <p>{community.mission}</p>
        </div>
        <div className="card details-section">
          <h3 className="section-title"><BookOpen size={20} className="text-violet" /> Objectives</h3>
          <ul className="details-list">
            {community.objectives.map((obj, i) => (
              <li key={i}><CheckCircle2 size={16} className="text-success" /> {obj}</li>
            ))}
          </ul>
        </div>
      </div>

      <div className="grid grid-2" style={{ marginTop: '20px' }}>
        <div className="card details-section">
          <h3 className="section-title"><Shield size={20} className="text-violet" /> Rules & Eligibility</h3>
          <ul className="details-list">
            {community.rules.map((rule, i) => (
              <li key={i}>{rule}</li>
            ))}
          </ul>
          <p className="eligibility"><strong>Eligibility:</strong> {community.eligibility}</p>
        </div>
        <div className="card details-section">
          <h3 className="section-title"><Wrench size={20} className="text-violet" /> Technologies & Interests</h3>
          <div className="tech-tags">
            {community.technologies.map((tech) => (
              <span key={tech} className="badge badge-violet">{tech}</span>
            ))}
          </div>
          <h4 style={{ marginTop: '16px', marginBottom: '8px' }}>Interests</h4>
          <div className="tech-tags">
            {community.interests.map((int) => (
              <span key={int} className="badge badge-blue">{int}</span>
            ))}
          </div>
        </div>
      </div>

      <div className="card details-section" style={{ marginTop: '20px' }}>
        <h3 className="section-title"><Users size={20} className="text-violet" /> Member Directory</h3>
        <div className="member-grid">
          {community.membersList.map((m) => (
            <div key={m.name} className="member-item">
              <div className="member-avatar">{m.avatar}</div>
              <div>
                <div className="member-name">{m.name}</div>
                <div className="member-role">{m.role}</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {communityEvents.length > 0 && (
        <div className="card details-section" style={{ marginTop: '20px' }}>
          <h3 className="section-title"><Calendar size={20} className="text-violet" /> Upcoming Events</h3>
          <div className="event-list">
            {communityEvents.map((event) => (
              <Link to={`/events/${event.id}`} key={event.id} className="event-list-item">
                <div className="event-list-date">
                  <span className="event-day">{new Date(event.date).getDate()}</span>
                  <span className="event-month">{new Date(event.date).toLocaleString('en-US', { month: 'short' })}</span>
                </div>
                <div className="event-list-info">
                  <h4>{event.title}</h4>
                  <p>{event.venue}</p>
                </div>
                <span className="badge badge-violet">{event.category}</span>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
