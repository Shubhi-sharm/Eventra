export const STORAGE_KEYS = {
  USER: 'eventra_user',
  USERS: 'eventra_users',
  JOINED_COMMUNITIES: 'eventra_joined_communities',
  REGISTRATIONS: 'eventra_registrations',
  TEAMS: 'eventra_teams',
  INVITATIONS: 'eventra_invitations',
  MENTOR_REQUESTS: 'eventra_mentor_requests',
  NOTIFICATIONS: 'eventra_notifications',
  PROFILE: 'eventra_profile',
}

export const ROLES = {
  MEMBER: 'member',
  MENTOR: 'mentor',
  PARTICIPANT: 'participant',
}

export const ROLE_LABELS = {
  member: 'Member',
  mentor: 'Mentor',
  participant: 'Participant',
}

export const EVENT_CATEGORIES = [
  'Hackathons',
  'Technical Quizzes',
  'Workshops',
  'Webinars',
  'Coding Competitions',
  'Tech Talks',
]

export const TEAM_ROLES = [
  'Frontend',
  'Backend',
  'AI/ML',
  'UI/UX',
  'Research',
  'Presentation',
  'DevOps',
  'Mobile',
]
