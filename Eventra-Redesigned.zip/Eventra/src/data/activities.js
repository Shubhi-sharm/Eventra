export const recentActivities = [
  { id: 1, type: 'join', message: 'You joined AI Innovators community', time: '2 hours ago', icon: 'Users' },
  { id: 2, type: 'register', message: 'Registered for AI Innovators Hackathon 2026', time: '5 hours ago', icon: 'Calendar' },
  { id: 3, type: 'team', message: 'Created team "Neural Nomads" for hackathon', time: '1 day ago', icon: 'Users' },
  { id: 4, type: 'mentor', message: 'Sent mentorship request to Dr. Sarah Chen', time: '2 days ago', icon: 'GraduationCap' },
  { id: 5, type: 'event', message: 'React Masterclass workshop is tomorrow', time: '3 days ago', icon: 'Bell' },
]
