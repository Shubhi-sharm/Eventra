export const potentialTeammates = [
  {
    id: 'p1',
    name: 'Alex Johnson',
    avatar: 'AJ',
    skills: ['React', 'TypeScript', 'Node.js', 'Tailwind CSS'],
    interests: ['Web Apps', 'AI Tools', 'Open Source'],
    preferredRoles: ['Frontend', 'UI/UX'],
    bio: 'Full-stack developer passionate about building delightful interfaces.',
    github: 'alexj',
    linkedin: 'alexjohnson',
    baseScore: 85,
  },
  {
    id: 'p2',
    name: 'Maria Garcia',
    avatar: 'MG',
    skills: ['Python', 'PyTorch', 'TensorFlow', 'NLP'],
    interests: ['AI/ML', 'Research', 'Generative AI'],
    preferredRoles: ['AI/ML', 'Research'],
    bio: 'ML researcher exploring the frontiers of generative models.',
    github: 'mariag',
    linkedin: 'mariagarcia',
    baseScore: 78,
  },
  {
    id: 'p3',
    name: 'James Lee',
    avatar: 'JL',
    skills: ['Node.js', 'Python', 'PostgreSQL', 'Docker'],
    interests: ['Backend', 'DevOps', 'Scalable Systems'],
    preferredRoles: ['Backend', 'DevOps'],
    bio: 'Backend engineer who loves building robust APIs and systems.',
    github: 'jamesl',
    linkedin: 'jameslee',
    baseScore: 72,
  },
  {
    id: 'p4',
    name: 'Priya Patel',
    avatar: 'PP',
    skills: ['Figma', 'React', 'CSS', 'Design Systems'],
    interests: ['UI/UX', 'Design', 'Accessibility'],
    preferredRoles: ['UI/UX', 'Frontend'],
    bio: 'UI/UX designer and frontend developer bridging design and code.',
    github: 'priyap',
    linkedin: 'priyapatel',
    baseScore: 90,
  },
  {
    id: 'p5',
    name: 'David Kim',
    avatar: 'DK',
    skills: ['Python', 'R', 'SQL', 'Pandas', 'Tableau'],
    interests: ['Data Science', 'Analytics', 'Visualization'],
    preferredRoles: ['Research', 'Presentation'],
    bio: 'Data scientist who loves turning numbers into narratives.',
    github: 'davidk',
    linkedin: 'davidkim',
    baseScore: 68,
  },
  {
    id: 'p6',
    name: 'Sophia Brown',
    avatar: 'SB',
    skills: ['React Native', 'Swift', 'Kotlin', 'Flutter'],
    interests: ['Mobile', 'Cross-Platform', 'App Design'],
    preferredRoles: ['Mobile', 'Frontend'],
    bio: 'Mobile developer crafting experiences for iOS and Android.',
    github: 'sophiab',
    linkedin: 'sophiabrown',
    baseScore: 80,
  },
]

export function calculateCompatibility(teamPrefs, teammate) {
  const teamSkills = (teamPrefs.technologies || []).map((s) => s.toLowerCase())
  const teamInterests = (teamPrefs.interests || []).map((s) => s.toLowerCase())
  const teamRoles = (teamPrefs.roles || [])

  const skillOverlap = teammate.skills.filter((s) => teamSkills.includes(s.toLowerCase())).length
  const interestOverlap = teammate.interests.filter((i) => teamInterests.includes(i.toLowerCase())).length
  const roleMatch = teammate.preferredRoles.some((r) => teamRoles.includes(r)) ? 1 : 0

  const skillScore = teamSkills.length > 0 ? (skillOverlap / teamSkills.length) * 50 : 25
  const interestScore = teamInterests.length > 0 ? (interestOverlap / teamInterests.length) * 30 : 15
  const roleScore = roleMatch * 20

  const finalScore = Math.min(99, Math.round(skillScore + interestScore + roleScore + teammate.baseScore * 0.1))
  return Math.max(40, finalScore)
}
