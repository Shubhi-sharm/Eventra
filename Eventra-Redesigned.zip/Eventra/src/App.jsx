import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import DashboardLayout from './layouts/DashboardLayout'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Profile from './pages/Profile'
import AllCommunities from './pages/AllCommunities'
import CommunityDetails from './pages/CommunityDetails'
import MyCommunities from './pages/MyCommunities'
import Events from './pages/Events'
import EventDetails from './pages/EventDetails'
import MyRegistrations from './pages/MyRegistrations'
import TeamFormation from './pages/TeamFormation'
import Mentors from './pages/Mentors'
import MentorDetails from './pages/MentorDetails'
import Notifications from './pages/Notifications'
import Settings from './pages/Settings'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route element={<DashboardLayout />}>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/communities" element={<AllCommunities />} />
        <Route path="/communities/:id" element={<CommunityDetails />} />
        <Route path="/my-communities" element={<MyCommunities />} />
        <Route path="/events" element={<Events />} />
        <Route path="/events/:id" element={<EventDetails />} />
        <Route path="/my-registrations" element={<MyRegistrations />} />
        <Route path="/team-formation" element={<TeamFormation />} />
        <Route path="/mentors" element={<Mentors />} />
        <Route path="/mentors/:id" element={<MentorDetails />} />
        <Route path="/notifications" element={<Notifications />} />
        <Route path="/settings" element={<Settings />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
