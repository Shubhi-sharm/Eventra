import React, { createContext, useContext, useCallback, useMemo } from 'react'
import { useLocalStorage } from '../hooks/useLocalStorage'
import { STORAGE_KEYS, ROLES } from '../data/constants'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [user, setUser] = useLocalStorage(STORAGE_KEYS.USER, null)
  const [users, setUsers] = useLocalStorage(STORAGE_KEYS.USERS, [])
  const [joinedCommunities, setJoinedCommunities] = useLocalStorage(STORAGE_KEYS.JOINED_COMMUNITIES, [])
  const [registrations, setRegistrations] = useLocalStorage(STORAGE_KEYS.REGISTRATIONS, [])
  const [teams, setTeams] = useLocalStorage(STORAGE_KEYS.TEAMS, [])
  const [invitations, setInvitations] = useLocalStorage(STORAGE_KEYS.INVITATIONS, [])
  const [mentorRequests, setMentorRequests] = useLocalStorage(STORAGE_KEYS.MENTOR_REQUESTS, [])
  const [notifications, setNotifications] = useLocalStorage(STORAGE_KEYS.NOTIFICATIONS, [
    { id: 1, title: 'Welcome to Eventra!', message: 'Start by exploring communities and events.', type: 'info', read: false, time: 'Just now' },
    { id: 2, title: 'New Hackathon', message: 'AI Innovators Hackathon registration is open.', type: 'event', read: false, time: '2h ago' },
  ])
  const [profile, setProfile] = useLocalStorage(STORAGE_KEYS.PROFILE, null)

  const login = useCallback((email, password) => {
    const found = users.find((u) => u.email === email && u.password === password)
    if (found) {
      setUser(found)
      setProfile(found)
      return { success: true, user: found }
    }
    return { success: false, error: 'Invalid email or password.' }
  }, [users, setUser, setProfile])

  const register = useCallback((userData) => {
    const newUser = { ...userData, id: Date.now(), role: userData.role }
    setUsers((prev) => [...prev, newUser])
    setUser(newUser)
    setProfile(newUser)
    return { success: true, user: newUser }
  }, [setUsers, setUser, setProfile])

  const logout = useCallback(() => {
    setUser(null)
  }, [setUser])

  const updateProfile = useCallback((updates) => {
    const updated = { ...user, ...updates }
    setUser(updated)
    setProfile(updated)
    return updated
  }, [user, setUser, setProfile])

  const joinCommunity = useCallback((communityId) => {
    setJoinedCommunities((prev) => {
      if (prev.includes(communityId)) return prev
      return [...prev, communityId]
    })
  }, [setJoinedCommunities])

  const leaveCommunity = useCallback((communityId) => {
    setJoinedCommunities((prev) => prev.filter((id) => id !== communityId))
  }, [setJoinedCommunities])

  const isCommunityJoined = useCallback((communityId) => {
    return joinedCommunities.includes(communityId)
  }, [joinedCommunities])

  const registerForEvent = useCallback((eventId) => {
    setRegistrations((prev) => {
      if (prev.includes(eventId)) return prev
      return [...prev, eventId]
    })
  }, [setRegistrations])

  const unregisterFromEvent = useCallback((eventId) => {
    setRegistrations((prev) => prev.filter((id) => id !== eventId))
  }, [setRegistrations])

  const isEventRegistered = useCallback((eventId) => {
    return registrations.includes(eventId)
  }, [registrations])

  const createTeam = useCallback((teamData) => {
    const newTeam = { ...teamData, id: Date.now(), members: [user?.id], createdAt: new Date().toISOString() }
    setTeams((prev) => [...prev, newTeam])
    return newTeam
  }, [setTeams, user])

  const sendInvitation = useCallback((invitation) => {
    setInvitations((prev) => [...prev, { ...invitation, id: Date.now(), status: 'pending', sentAt: new Date().toISOString() }])
  }, [setInvitations])

  const acceptInvitation = useCallback((invId) => {
    setInvitations((prev) => prev.map((i) => (i.id === invId ? { ...i, status: 'accepted' } : i)))
  }, [setInvitations])

  const declineInvitation = useCallback((invId) => {
    setInvitations((prev) => prev.map((i) => (i.id === invId ? { ...i, status: 'declined' } : i)))
  }, [setInvitations])

  const requestMentorship = useCallback((mentorId) => {
    setMentorRequests((prev) => {
      if (prev.some((r) => r.mentorId === mentorId)) return prev
      return [...prev, { id: Date.now(), mentorId, status: 'pending', requestedAt: new Date().toISOString() }]
    })
  }, [setMentorRequests])

  const getMentorshipRequestStatus = useCallback((mentorId) => {
    const req = mentorRequests.find((r) => r.mentorId === mentorId)
    return req ? req.status : null
  }, [mentorRequests])

  const markNotificationRead = useCallback((id) => {
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, read: true } : n)))
  }, [setNotifications])

  const markAllNotificationsRead = useCallback(() => {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })))
  }, [setNotifications])

  const unreadNotificationsCount = useMemo(() => {
    return notifications.filter((n) => !n.read).length
  }, [notifications])

  const value = {
    user,
    profile,
    login,
    register,
    logout,
    updateProfile,
    joinedCommunities,
    joinCommunity,
    leaveCommunity,
    isCommunityJoined,
    registrations,
    registerForEvent,
    unregisterFromEvent,
    isEventRegistered,
    teams,
    createTeam,
    invitations,
    sendInvitation,
    acceptInvitation,
    declineInvitation,
    mentorRequests,
    requestMentorship,
    getMentorshipRequestStatus,
    notifications,
    markNotificationRead,
    markAllNotificationsRead,
    unreadNotificationsCount,
  }

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AppProvider')
  return ctx
}
