import React from 'react'
import { Send, Check, X, Github, Linkedin, ExternalLink } from 'lucide-react'

export default function TeamMatchCard({ teammate, score, onInvite, inviteStatus }) {
  return (
    <div className="card team-match-card">
      <div className="team-match-header">
        <div className="teammate-avatar">{teammate.avatar}</div>
        <div className="teammate-info">
          <h4 className="teammate-name">{teammate.name}</h4>
          <p className="teammate-bio">{teammate.bio}</p>
        </div>
      </div>
      <div className="compatibility-score">
        <div className="score-label">Compatibility Score (Demo)</div>
        <div className="score-ring" style={{ background: `conic-gradient(var(--violet-600) ${score * 3.6}deg, var(--surface-alt) 0deg)` }}>
          <div className="score-inner">{score}%</div>
        </div>
      </div>
      <div className="teammate-profile-links">
        <a href={`https://github.com/${teammate.github}`} target="_blank" rel="noreferrer" aria-label={`${teammate.name} GitHub`}><Github size={15} /> GitHub <ExternalLink size={11} /></a>
        <a href={`https://www.linkedin.com/in/${teammate.linkedin}`} target="_blank" rel="noreferrer" aria-label={`${teammate.name} LinkedIn`}><Linkedin size={15} /> LinkedIn <ExternalLink size={11} /></a>
      </div>
      <div className="teammate-skills">
        <div className="skills-group">
          <span className="skills-label">Skills:</span>
          {teammate.skills.map((s) => (
            <span key={s} className="badge badge-violet">{s}</span>
          ))}
        </div>
        <div className="skills-group">
          <span className="skills-label">Interests:</span>
          {teammate.interests.map((i) => (
            <span key={i} className="badge badge-blue">{i}</span>
          ))}
        </div>
        <div className="skills-group">
          <span className="skills-label">Roles:</span>
          {teammate.preferredRoles.map((r) => (
            <span key={r} className="badge badge-green">{r}</span>
          ))}
        </div>
      </div>
      <div className="team-match-actions">
        {inviteStatus === 'pending' ? (
          <button className="btn btn-secondary btn-sm" disabled>
            <Check size={14} /> Invitation Sent
          </button>
        ) : inviteStatus === 'accepted' ? (
          <span className="badge badge-green"><Check size={12} /> Connected</span>
        ) : (
          <button className="btn btn-primary btn-sm" onClick={onInvite}>
            <Send size={14} /> Send Invite
          </button>
        )}
      </div>
    </div>
  )
}
