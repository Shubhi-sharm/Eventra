import React from 'react'
import { Link } from 'react-router-dom'
import { MapPin, Users, Calendar } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function CommunityCard({ community }) {
  const { isCommunityJoined, joinCommunity, leaveCommunity } = useApp()
  const joined = isCommunityJoined(community.id)

  return (
    <div className="card community-card">
      <div className="community-card-header">
        <div className="community-logo">{community.logo}</div>
        <div className="community-card-info">
          <h3 className="community-name">{community.name}</h3>
          <span className="badge badge-violet">{community.category}</span>
        </div>
      </div>
      <p className="community-description">{community.description}</p>
      <div className="community-meta">
        <span><Users size={14} /> {community.members.toLocaleString()} members</span>
        <span><MapPin size={14} /> {community.lead}</span>
        <span><Calendar size={14} /> {community.upcomingEvents} upcoming</span>
      </div>
      <div className="community-card-actions">
        <Link to={`/communities/${community.id}`} className="btn btn-secondary btn-sm">View Details</Link>
        {joined ? (
          <button className="btn btn-danger btn-sm" onClick={() => leaveCommunity(community.id)}>Leave</button>
        ) : (
          <button className="btn btn-primary btn-sm" onClick={() => joinCommunity(community.id)}>Join Community</button>
        )}
      </div>
    </div>
  )
}
