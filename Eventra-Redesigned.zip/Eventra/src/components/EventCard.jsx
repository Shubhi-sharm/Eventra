import React from 'react'
import { Link } from 'react-router-dom'
import { Calendar, MapPin, Users, Clock } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function EventCard({ event }) {
  const { isEventRegistered, registerForEvent, unregisterFromEvent } = useApp()
  const registered = isEventRegistered(event.id)
  const isFull = event.participants >= event.maxParticipants

  return (
    <div className="card event-card">
      <div className="event-card-header">
        <span className="badge badge-violet">{event.category}</span>
        {event.online ? (
          <span className="badge badge-green">Online</span>
        ) : (
          <span className="badge badge-slate">In-Person</span>
        )}
      </div>
      <h3 className="event-title">{event.title}</h3>
      <p className="event-organizer">by {event.organizer}</p>
      <p className="event-description">{event.description}</p>
      <div className="event-meta">
        <span><Calendar size={14} /> {new Date(event.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span>
        <span><Clock size={14} /> Deadline: {new Date(event.deadline).toLocaleDateString()}</span>
        <span><MapPin size={14} /> {event.venue}</span>
        <span><Users size={14} /> {event.participants}/{event.maxParticipants}</span>
      </div>
      <div className="event-card-actions">
        <Link to={`/events/${event.id}`} className="btn btn-secondary btn-sm">View Details</Link>
        {registered ? (
          <button className="btn btn-danger btn-sm" onClick={() => unregisterFromEvent(event.id)}>Unregister</button>
        ) : (
          <button
            className="btn btn-primary btn-sm"
            disabled={isFull}
            onClick={() => registerForEvent(event.id)}
          >
            {isFull ? 'Full' : 'Register'}
          </button>
        )}
      </div>
    </div>
  )
}
