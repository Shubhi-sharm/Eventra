import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { ROLES } from '../data/constants'
import { TEAM_ROLES } from '../data/constants'
import { useApp } from '../context/AppContext'
import { CheckCircle2, AlertCircle } from 'lucide-react'

const commonFields = [
  { name: 'fullName', label: 'Full Name', type: 'text', required: true, placeholder: 'John Doe' },
  { name: 'email', label: 'Email', type: 'email', required: true, placeholder: 'you@example.com' },
  { name: 'phone', label: 'Phone Number', type: 'tel', required: true, placeholder: '+1 234 567 890' },
  { name: 'college', label: 'College / University', type: 'text', required: true, placeholder: 'Your institution' },
  { name: 'branch', label: 'Branch', type: 'text', required: true, placeholder: 'e.g. Computer Science' },
  { name: 'academicYear', label: 'Academic Year', type: 'select', required: true, options: ['1st Year', '2nd Year', '3rd Year', '4th Year', 'Graduate', 'Postgraduate'] },
  { name: 'password', label: 'Password', type: 'password', required: true, placeholder: 'Min. 6 characters' },
]

const participantFields = [
  { name: 'technicalSkills', label: 'Technical Skills', type: 'text', required: false, placeholder: 'React, Python, Node.js' },
  { name: 'github', label: 'GitHub Profile URL', type: 'url', required: false, placeholder: 'https://github.com/username' },
  { name: 'linkedin', label: 'LinkedIn Profile URL', type: 'url', required: false, placeholder: 'https://linkedin.com/in/username' },
  { name: 'portfolio', label: 'Portfolio URL', type: 'url', required: false, placeholder: 'https://yourportfolio.com' },
  { name: 'interests', label: 'Interests', type: 'text', required: false, placeholder: 'AI, Web Dev, Open Source' },
  { name: 'preferredRoles', label: 'Preferred Team Roles', type: 'multiselect', required: false, options: TEAM_ROLES },
]

const mentorFields = [
  { name: 'qualification', label: 'Highest Qualification', type: 'text', required: true, placeholder: 'Ph.D. in Computer Science' },
  { name: 'education', label: 'Educational Background', type: 'text', required: true, placeholder: 'University, Year' },
  { name: 'specialization', label: 'Specialization', type: 'text', required: true, placeholder: 'e.g. NLP, Web Architecture' },
  { name: 'experience', label: 'Professional Experience', type: 'text', required: true, placeholder: 'e.g. 10 years in...' },
  { name: 'expertise', label: 'Areas of Expertise', type: 'text', required: true, placeholder: 'Python, ML, System Design' },
  { name: 'bio', label: 'Bio', type: 'textarea', required: false, placeholder: 'Tell us about yourself...' },
  { name: 'availability', label: 'Availability', type: 'text', required: false, placeholder: 'e.g. Weekday evenings' },
  { name: 'studentsMentored', label: 'Number of Students Mentored', type: 'number', required: false, placeholder: '0' },
]

const memberFields = [
  { name: 'communityInterests', label: 'Community Interests', type: 'text', required: true, placeholder: 'AI, Web Dev, Cybersecurity' },
  { name: 'technicalSkills', label: 'Technical Skills', type: 'text', required: false, placeholder: 'Your skills' },
  { name: 'contributionAreas', label: 'Areas of Contribution', type: 'text', required: false, placeholder: 'Content, Events, Mentorship' },
  { name: 'preferredResponsibilities', label: 'Preferred Responsibilities', type: 'text', required: false, placeholder: 'Organizing, Volunteering' },
]

export default function RegistrationForm({ role }) {
  const { register } = useApp()
  const navigate = useNavigate()
  const [form, setForm] = useState({})
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const getFields = () => {
    if (role === ROLES.PARTICIPANT) return [...commonFields, ...participantFields]
    if (role === ROLES.MENTOR) return [...commonFields, ...mentorFields]
    return [...commonFields, ...memberFields]
  }

  const fields = getFields()

  const validate = () => {
    const e = {}
    fields.forEach((f) => {
      if (f.required) {
        const val = form[f.name]
        if (!val || (Array.isArray(val) && val.length === 0)) {
          e[f.name] = `${f.label} is required`
        }
      }
      if (f.type === 'email' && form[f.name] && !/\S+@\S+\.\S+/.test(form[f.name])) {
        e[f.name] = 'Invalid email format'
      }
      if (f.name === 'password' && form[f.name] && form[f.name].length < 6) {
        e[f.name] = 'Password must be at least 6 characters'
      }
    })
    return e
  }

  const handleChange = (name, value) => {
    setForm((prev) => ({ ...prev, [name]: value }))
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }))
  }

  const handleMultiSelect = (name, value) => {
    setForm((prev) => {
      const current = prev[name] || []
      const updated = current.includes(value) ? current.filter((v) => v !== value) : [...current, value]
      return { ...prev, [name]: updated }
    })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    const validationErrors = validate()
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors)
      return
    }
    setErrors({})
    setLoading(true)
    setTimeout(() => {
      register({ ...form, role })
      setLoading(false)
      setSuccess(true)
      setTimeout(() => navigate('/dashboard'), 1200)
    }, 800)
  }

  if (success) {
    return (
      <div className="success-state">
        <CheckCircle2 size={64} className="success-icon" />
        <h2>Registration Successful!</h2>
        <p>Welcome to Eventra! Redirecting to your dashboard...</p>
      </div>
    )
  }

  return (
    <form className="registration-form" onSubmit={handleSubmit}>
      <div className="form-section-title">
        <h2>{role === ROLES.MENTOR ? 'Mentor' : role === ROLES.PARTICIPANT ? 'Participant' : 'Member'} Registration</h2>
        <p>Fill in your details to get started</p>
      </div>

      {fields.map((field) => (
        <div key={field.name} className="form-group">
          <label className="form-label">
            {field.label} {field.required && <span className="required">*</span>}
          </label>
          {field.type === 'select' && (
            <select
              className="form-select"
              value={form[field.name] || ''}
              onChange={(e) => handleChange(field.name, e.target.value)}
            >
              <option value="">Select...</option>
              {field.options.map((opt) => (
                <option key={opt} value={opt}>{opt}</option>
              ))}
            </select>
          )}
          {field.type === 'textarea' && (
            <textarea
              className="form-textarea"
              value={form[field.name] || ''}
              onChange={(e) => handleChange(field.name, e.target.value)}
              placeholder={field.placeholder}
            />
          )}
          {field.type === 'multiselect' && (
            <div className="multiselect">
              {field.options.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  className={`chip ${(form[field.name] || []).includes(opt) ? 'chip-active' : ''}`}
                  onClick={() => handleMultiSelect(field.name, opt)}
                >
                  {opt}
                </button>
              ))}
            </div>
          )}
          {!['select', 'textarea', 'multiselect'].includes(field.type) && (
            <input
              type={field.type}
              className="form-input"
              value={form[field.name] || ''}
              onChange={(e) => handleChange(field.name, e.target.value)}
              placeholder={field.placeholder}
            />
          )}
          {errors[field.name] && (
            <div className="form-error"><AlertCircle size={12} /> {errors[field.name]}</div>
          )}
        </div>
      ))}

      <button type="submit" className="btn btn-primary btn-block" disabled={loading}>
        {loading ? <span className="loader"></span> : `Create ${role === ROLES.MENTOR ? 'Mentor' : role === ROLES.PARTICIPANT ? 'Participant' : 'Member'} Account`}
      </button>
    </form>
  )
}
