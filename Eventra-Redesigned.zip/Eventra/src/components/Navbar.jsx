import React, { useState, useRef, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Menu, Bell, Search, ChevronDown, LogOut, User } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function Navbar({ onMenuClick }) {
  const { user, logout, notifications, markNotificationRead, unreadNotificationsCount } = useApp()
  const navigate = useNavigate()
  const [showNotifications, setShowNotifications] = useState(false)
  const [showProfile, setShowProfile] = useState(false)
  const notifRef = useRef(null)
  const profileRef = useRef(null)

  useEffect(() => {
    const handleClick = (e) => {
      if (notifRef.current && !notifRef.current.contains(e.target)) setShowNotifications(false)
      if (profileRef.current && !profileRef.current.contains(e.target)) setShowProfile(false)
    }
    document.addEventListener('mousedown', handleClick)
    return () => document.removeEventListener('mousedown', handleClick)
  }, [])

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <header className="navbar">
      <div className="navbar-left">
        <button className="menu-btn" onClick={onMenuClick} aria-label="Toggle menu">
          <Menu size={22} />
        </button>
        <div className="search-box">
          <Search size={16} />
          <input type="text" placeholder="Search communities, events, mentors..." />
        </div>
      </div>

      <div className="navbar-right">
        <div className="notif-wrapper" ref={notifRef}>
          <button className="icon-btn" onClick={() => setShowNotifications(!showNotifications)} aria-label="Notifications">
            <Bell size={20} />
            {unreadNotificationsCount > 0 && <span className="icon-badge">{unreadNotificationsCount}</span>}
          </button>
          {showNotifications && (
            <div className="dropdown notif-dropdown">
              <div className="dropdown-header">
                <span>Notifications</span>
                <button className="text-muted" onClick={() => notifications.forEach((n) => markNotificationRead(n.id))}>
                  Mark all read
                </button>
              </div>
              <div className="dropdown-list">
                {notifications.slice(0, 5).map((n) => (
                  <div key={n.id} className={`notif-item ${n.read ? '' : 'unread'}`} onClick={() => markNotificationRead(n.id)}>
                    <div className="notif-title">{n.title}</div>
                    <div className="notif-message">{n.message}</div>
                    <div className="notif-time">{n.time}</div>
                  </div>
                ))}
              </div>
              <button className="dropdown-footer" onClick={() => { setShowNotifications(false); navigate('/notifications') }}>
                View all notifications
              </button>
            </div>
          )}
        </div>

        <div className="profile-wrapper" ref={profileRef}>
          <button className="profile-btn" onClick={() => setShowProfile(!showProfile)}>
            <div className="profile-avatar">{user?.fullName?.charAt(0).toUpperCase() || 'U'}</div>
            <span className="profile-name hide-mobile">{user?.fullName || 'User'}</span>
            <ChevronDown size={16} />
          </button>
          {showProfile && (
            <div className="dropdown profile-dropdown">
              <button className="dropdown-item" onClick={() => { setShowProfile(false); navigate('/profile') }}>
                <User size={16} /> My Profile
              </button>
              <button className="dropdown-item" onClick={handleLogout}>
                <LogOut size={16} /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  )
}
