import React from 'react'
import { NavLink, useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  User,
  Users,
  Globe,
  UserCheck,
  Calendar,
  ClipboardList,
  Sparkles,
  GraduationCap,
  Bell,
  Settings,
  LogOut,
  ChevronRight,
  X,
} from 'lucide-react'
import { useApp } from '../context/AppContext'

const navItems = [
  { to: '/dashboard', label: 'Overview', icon: LayoutDashboard },
  { to: '/profile', label: 'My Profile', icon: User },
  {
    section: 'Communities',
    children: [
      { to: '/communities', label: 'All Communities', icon: Globe },
      { to: '/my-communities', label: 'My Communities', icon: UserCheck },
    ],
  },
  {
    section: 'Events',
    children: [
      { to: '/events', label: 'Events', icon: Calendar },
      { to: '/my-registrations', label: 'My Registrations', icon: ClipboardList },
    ],
  },
  { to: '/team-formation', label: 'AI Team Formation', icon: Sparkles },
  { to: '/mentors', label: 'Mentors', icon: GraduationCap },
  { to: '/notifications', label: 'Notifications', icon: Bell },
  { to: '/settings', label: 'Settings', icon: Settings },
]

export default function Sidebar({ isOpen, onClose }) {
  const { user, logout, unreadNotificationsCount } = useApp()
  const navigate = useNavigate()

  const handleLogout = () => {
    logout()
    navigate('/')
  }

  return (
    <>
      {isOpen && <div className="sidebar-overlay" onClick={onClose} />}
      <aside className={`sidebar ${isOpen ? 'sidebar-open' : ''}`}>
        <div className="sidebar-header">
          <div className="sidebar-logo">
            <span className="logo-mark">E</span>
            <span className="logo-text">Eventra</span>
          </div>
          <button className="sidebar-close" onClick={onClose} aria-label="Close sidebar">
            <X size={20} />
          </button>
        </div>

        {user && (
          <div className="sidebar-user">
            <div className="sidebar-user-avatar">{user.fullName?.charAt(0).toUpperCase() || 'U'}</div>
            <div className="sidebar-user-info">
              <div className="sidebar-user-name">{user.fullName}</div>
              <div className="sidebar-user-role">{user.role ? user.role.charAt(0).toUpperCase() + user.role.slice(1) : 'User'}</div>
            </div>
          </div>
        )}

        <nav className="sidebar-nav">
          {navItems.map((item, idx) =>
            item.section ? (
              <div key={idx} className="nav-section">
                <div className="nav-section-title">{item.section}</div>
                {item.children.map((child) => (
                  <NavLink
                    key={child.to}
                    to={child.to}
                    className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
                    onClick={onClose}
                  >
                    <child.icon size={18} />
                    <span>{child.label}</span>
                  </NavLink>
                ))}
              </div>
            ) : (
              <NavLink
                key={item.to}
                to={item.to}
                className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
                onClick={onClose}
              >
                <item.icon size={18} />
                <span>{item.label}</span>
                {item.to === '/notifications' && unreadNotificationsCount > 0 && (
                  <span className="nav-badge">{unreadNotificationsCount}</span>
                )}
              </NavLink>
            )
          )}
        </nav>

        <div className="sidebar-footer">
          <button className="nav-item logout-btn" onClick={handleLogout}>
            <LogOut size={18} />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  )
}
