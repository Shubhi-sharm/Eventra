import React from 'react'
import { TrendingUp } from 'lucide-react'

export default function StatCard({ icon: Icon, label, value, change, color = 'violet' }) {
  const colorMap = {
    violet: { bg: 'var(--violet-100)', fg: 'var(--violet-700)' },
    blue: { bg: 'var(--info-bg)', fg: 'var(--info)' },
    green: { bg: 'var(--success-bg)', fg: 'var(--success)' },
    amber: { bg: 'var(--warning-bg)', fg: 'var(--warning)' },
  }
  const colors = colorMap[color] || colorMap.violet

  return (
    <div className="card stat-card">
      <div className="stat-icon" style={{ background: colors.bg, color: colors.fg }}>
        <Icon size={22} />
      </div>
      <div className="stat-content">
        <div className="stat-label">{label}</div>
        <div className="stat-value">{value}</div>
        {change && (
          <div className="stat-change">
            <TrendingUp size={14} /> {change}
          </div>
        )}
      </div>
    </div>
  )
}
