import React from 'react'
import { Link } from 'react-router-dom'
import { Star, Briefcase } from 'lucide-react'
import { useApp } from '../context/AppContext'

export default function MentorCard({ mentor }) {
  const { getMentorshipRequestStatus } = useApp()
  const status = getMentorshipRequestStatus(mentor.id)

  return (
    <div className="card mentor-card">
      <div className="mentor-card-header">
        <div className="mentor-avatar">{mentor.avatar}</div>
        <div className="mentor-card-info">
          <h3 className="mentor-name">{mentor.name}</h3>
          <p className="mentor-title">{mentor.title}</p>
          <p className="mentor-company"><Briefcase size={12} /> {mentor.company}</p>
        </div>
        <div className="mentor-rating">
          <Star size={16} fill="var(--warning)" color="var(--warning)" /> {mentor.rating}
        </div>
      </div>
      <div className="mentor-expertise">
        {mentor.expertise.slice(0, 4).map((exp) => (
          <span key={exp} className="badge badge-slate">{exp}</span>
        ))}
      </div>
      <div className="mentor-card-actions">
        <Link to={`/mentors/${mentor.id}`} className="btn btn-secondary btn-sm">View Profile</Link>
        {status === 'pending' && <span className="badge badge-amber">Request Pending</span>}
        {status === 'accepted' && <span className="badge badge-green">Connected</span>}
      </div>
    </div>
  )
}
