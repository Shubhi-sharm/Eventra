# Eventra — OrbitOS-inspired redesign

This is your existing Eventra React + Vite project, updated with a dark navy/purple/cyan dashboard theme inspired by the supplied OrbitOS reference.

## Run locally
1. Extract the ZIP.
2. Open the `Eventra` folder in VS Code.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL printed by Vite.

## Changes made
- Reworked theme tokens to a dark navy, indigo, violet and cyan palette.
- Added OrbitOS-inspired dashboard styling: dark sidebar, glowing purple active navigation, dark cards, subtle borders and gradient buttons.
- Kept the existing routes, data, registration flows, communities, events, mentors, profile and dashboard structure.
- Added a LinkedIn/GitHub profile criteria panel to Team Formation.
- Added configurable matching signals for skills, projects, experience/education, role coverage, and availability/interests.
- Added GitHub and LinkedIn profile links to sample teammate cards.
- Saved the profile URLs and matching criteria in browser localStorage when the user clicks Save matching criteria.

## Important limitations
This is still a frontend prototype. It does not scrape LinkedIn or fetch GitHub API data. Profile links and matching criteria are saved locally in the browser. Real authorized API integrations and server-side matching require backend work. Existing teammate scores remain demo scores and should not be presented as verified AI predictions.

## Build check
The updated JSX files were syntax-parsed successfully. A production build could not be verified in this environment because the supplied dependencies lack the platform-specific Rollup binary. Run `npm install` locally before `npm run build` to install the correct dependencies for your system.
