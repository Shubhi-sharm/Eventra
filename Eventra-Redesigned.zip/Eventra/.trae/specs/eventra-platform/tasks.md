# Eventra - Implementation Plan

## Task 1: Project scaffolding and global setup
- **Status**: `completed`
- **Priority**: high
- **Depends On**: None
- **Description**:
  - Initialize Vite + React project (package.json, vite.config.js, index.html, main.jsx, App.jsx)
  - Install dependencies: react, react-dom, react-router-dom, lucide-react
  - Create global styles, CSS variables (navy/violet/lavender/white palette), reset
  - Create folder structure: components/, pages/, layouts/, data/, context/, hooks/, styles/
- **Acceptance Criteria Addressed**: AC-10, AC-11, AC-12
- **Completion Evidence**:
  - `npm install` succeeded (67 packages); `npm run dev` starts cleanly
  - Folder structure created: components/, pages/, layouts/, data/, context/, hooks/, styles/
  - CSS variables for navy/violet/lavender/white palette in variables.css

## Task 2: Mock data and localStorage utilities
- **Status**: `completed`
- **Priority**: high
- **Depends On**: Task 1
- **Description**:
  - Create mock data: communities, events, mentors, teamMatches, activities
  - Create localStorage hooks/utils (useLocalStorage, auth storage, joined communities, registrations, teams, mentorship requests)
  - Create AppContext for auth/user state, notifications, global actions
- **Acceptance Criteria Addressed**: AC-2, AC-3, AC-5, AC-7, AC-8, AC-9
- **Completion Evidence**:
  - Mock data files: communities.js (6), events.js (12), mentors.js (6), teamMatches.js (6), activities.js (5)
  - useLocalStorage hook persists values across reload (verified via join/register flows)
  - AppContext provides all global state and actions

## Task 3: Landing page and role selection
- **Status**: `completed`
- **Priority**: high
- **Depends On**: Task 1
- **Description**:
  - Build Landing page with Eventra logo, heading, tagline, description
  - Build 3 role cards (Member, Mentor, Participant) with icons and CTA
  - CTA navigates to registration with role param
- **Acceptance Criteria Addressed**: AC-1
- **Completion Evidence**:
  - Landing page renders "Welcome to Eventra", tagline "Connect. Collaborate. Create."
  - 3 role cards (Member, Mentor, Participant) each with icon, description, CTA button
  - Clicking each role card navigates to /register?role={role}

## Task 4: Registration and login forms
- **Status**: `completed`
- **Priority**: high
- **Depends On**: Task 2
- **Description**:
  - Build RegistrationForm component with role-specific fields and validation
  - Build Login page with email/password validation
  - Loading states, success/error feedback
  - Persist registered user to localStorage; login checks against stored user
- **Acceptance Criteria Addressed**: AC-2, AC-3
- **Completion Evidence**:
  - Role-specific fields for member (community interests, skills, contribution areas), mentor (qualifications, experience, expertise, bio), participant (skills, GitHub, LinkedIn, roles)
  - Validation errors shown for empty required fields and invalid email
  - Successful registration stores user to localStorage and redirects to dashboard
  - Login with wrong credentials shows error; correct credentials redirect to dashboard (verified full register→logout→login flow)

## Task 5: Dashboard layout (Sidebar + Navbar + Dashboard page)
- **Status**: `completed`
- **Priority**: high
- **Depends On**: Task 2, Task 4
- **Description**:
  - Build Sidebar component with all sections, active states, mobile toggle
  - Build Navbar (top nav) with user menu, notifications
  - Build DashboardLayout wrapper
  - Build Dashboard page: StatCards, upcoming events, joined communities, recommended communities, recent activities, quick actions
- **Acceptance Criteria Addressed**: AC-4
- **Completion Evidence**:
  - Sidebar lists all 12 sections with active state highlighting
  - Mobile hamburger toggles sidebar overlay
  - Dashboard shows 4 stat cards, upcoming events, joined communities, recommended communities, recent activities, quick actions

## Task 6: Communities (All + Details + My Communities)
- **Status**: `completed`
- **Priority**: high
- **Depends On**: Task 5
- **Description**:
  - Build CommunityCard component
  - Build All Communities page with search + category filter
  - Build Community Details page (description, mission, rules, tech, members, events, Join/Leave)
  - Build My Communities page
  - Join/Leave logic with localStorage + duplicate prevention
- **Acceptance Criteria Addressed**: AC-5, AC-6
- **Completion Evidence**:
  - All Communities page with search and category filter
  - Join adds community to My Communities and localStorage; duplicate join prevented; Leave removes
  - Community Details page shows mission, objectives, rules, technologies, member directory, upcoming events, Join/Leave

## Task 7: Events (list + details + My Registrations)
- **Status**: `completed`
- **Priority**: high
- **Depends On**: Task 5
- **Description**:
  - Build EventCard component
  - Build Events page with category filters + search
  - Build Event Details page
  - Build My Registrations page
  - Register action with localStorage + duplicate prevention
- **Acceptance Criteria Addressed**: AC-7
- **Completion Evidence**:
  - Events page with all 6 category filters + search
  - Register adds event to My Registrations and localStorage; duplicate prevented
  - Event Details shows title, organizer, date, deadline, venue, description, eligibility, status
  - My Registrations page shows registered events with unregister option

## Task 8: AI Team Formation
- **Status**: `completed`
- **Priority**: medium
- **Depends On**: Task 5
- **Description**:
  - Build TeamMatchCard component
  - Build AI Team Formation page: create/join team, project ideas, preferred tech, role selection, potential teammates, compatibility score (demo-labeled), send/accept invitations
  - Persist teams and invitations to localStorage
- **Acceptance Criteria Addressed**: AC-8
- **Completion Evidence**:
  - Team formation page with create team, project ideas, preferred tech, role selection buttons
  - Potential teammates listed with compatibility scores labeled "Demo"
  - Send Invite buttons for each teammate; teams and invitations persisted to localStorage

## Task 9: Mentor Portal
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 5
- **Description**:
  - Build MentorCard component
  - Build Mentors page with search + expertise filter
  - Build Mentor Details page
  - Request Mentorship action with demo status persisted to localStorage
- **Acceptance Criteria Addressed**: AC-9
- **Test Requirements**:
  - `rule` TR-9.1: Search filters mentors by name; expertise filter works; evidence = filter interaction
  - `rule` TR-9.2: Mentor Details shows qualifications, experience, availability, interests; evidence = details render
  - `rule` TR-9.3: Request Mentorship sets demo status and persists; evidence = request flow
- **Notes**: Clear "demo" labeling on request status.

## Task 10: Profile, Notifications, Settings pages
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 5
- **Description**:
  - My Profile page with edit capability (persist to localStorage)
  - Notifications page with demo notifications
  - Settings page (profile preferences, demo only)
- **Acceptance Criteria Addressed**: AC-4, AC-16
- **Test Requirements**:
  - `rule` TR-10.1: Profile edit saves to localStorage and reflects on dashboard; evidence = edit flow
  - `rule` TR-10.2: Notifications page lists notifications; evidence = page render
- **Notes**: Keep settings demo-only.

## Task 11: Shared components, empty states, modal, polish
- **Status**: `pending`
- **Priority**: medium
- **Depends On**: Task 1
- **Description**:
  - Build reusable StatCard, EmptyState, Modal components
  - Ensure EmptyState used where lists are empty
  - Polish: consistent spacing, hover effects, gradients
- **Acceptance Criteria Addressed**: AC-10, AC-11, AC-12
- **Test Requirements**:
  - `rule` TR-11.1: StatCard, EmptyState, Modal components exist and render; evidence = component files
  - `rubric` TR-11.2: Visual polish; scale 1-5; anchors 1/3/5; threshold >= 4; evidence = visual inspection
- **Notes**: Apply consistently across pages.

## Task 12: Final build verification and console error check
- **Status**: `pending`
- **Priority**: high
- **Depends On**: Task 3, Task 4, Task 5, Task 6, Task 7, Task 8, Task 9, Task 10, Task 11
- **Description**:
  - Run `npm run build`, fix any errors
  - Start dev server, navigate all routes, check for console errors
  - Verify responsive breakpoints
- **Acceptance Criteria Addressed**: AC-10, AC-12
- **Test Requirements**:
  - `rule` TR-12.1: `npm run build` exits with code 0; evidence = build output
  - `rule` TR-12.2: No console errors on all main routes; evidence = browser console
  - `rubric` TR-12.3: Responsive at desktop/tablet/mobile; scale 1-5; threshold >= 4; evidence = browser resizing
- **Notes**: Fix all broken imports and blank pages.
