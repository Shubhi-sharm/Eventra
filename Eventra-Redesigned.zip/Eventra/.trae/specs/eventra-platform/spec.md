# Eventra - AI-Powered Tech Community & Event Management Platform

## Overview
- **Summary**: A complete, modern, responsive frontend for Eventra, an AI-powered platform that connects tech communities, mentors, participants, hackathons, workshops, quizzes, and intelligent team formation.
- **Purpose**: Provide a premium SaaS-style interface for tech community and event management with role-based access (Member, Mentor, Participant).
- **Target Users**: Tech community members, mentors, and participants (students/professionals).

## Goals
- Deliver a runnable React + Vite project with no broken imports, blank pages, nonfunctional buttons, or console errors.
- Implement landing page, role-based registration, dashboard, communities, events, AI team formation, and mentor portal.
- Use mock data and localStorage for frontend demonstration; keep API integration ready for future backend.

## Non-Goals
- Real backend API integration (mock data only).
- Real email sending, real notifications, real AI matching, or real authentication.
- Production deployment configuration beyond local dev server.

## Background & Context
- Fresh project in an empty directory.
- Technology: React.js with Vite, JavaScript, custom CSS, React Router, Lucide React icons.
- Design: deep navy, violet, lavender, white palette; clean sidebar, rounded cards, subtle shadows, gradients, smooth hover effects.

## Functional Requirements

### Landing & Authentication
- **FR-1**: Landing page displays large Eventra logo, heading "Welcome to Eventra", tagline "Connect. Collaborate. Create.", description, and three interactive role cards (Member, Mentor, Participant) each with icon, description, and CTA button opening the relevant registration form.
- **FR-2**: Registration forms with role-specific fields and validation. Common fields: full name, email, phone, college/university, branch, academic year, password. Participants add: technical skills, GitHub, LinkedIn, portfolio URLs, interests, preferred team roles. Mentors add: highest qualification, educational background, specialization, professional experience, areas of expertise, bio, availability, students mentored. Members add: community interests, technical skills, areas of contribution, preferred responsibilities.
- **FR-3**: Login form with email/password and validation.
- **FR-4**: Loading states, success/error feedback on forms.

### Dashboard
- **FR-5**: Dashboard with persistent sidebar (Overview, My Profile, Communities > All Communities / My Communities, Events > My Registrations, AI Team Formation, Mentors, Notifications, Settings) and top nav.
- **FR-6**: Dashboard statistics, upcoming events, joined communities, recommended communities, recent activities, quick-action buttons. Role-appropriate options.

### Communities
- **FR-7**: All Communities page with searchable/filterable cards (name, logo, description, category, member count, lead, upcoming events, Join button).
- **FR-8**: Community Details page (full description, mission, rules, technologies, member directory, upcoming events, Join/Leave action).
- **FR-9**: Join/leave updates UI and My Communities; prevent duplicate joins.

### Events
- **FR-10**: Events page with category filters (Hackathons, Technical Quizzes, Workshops, Webinars, Coding Competitions, Tech Talks).
- **FR-11**: Event cards (title, organizer, date, deadline, venue/online, description, eligibility, registration status).
- **FR-12**: Event Details page, Register action, My Registrations page, search/filters, empty/success states.

### AI Team Formation
- **FR-13**: Team formation interface: create/join team, add project ideas & preferred tech, select roles (Frontend, Backend, AI/ML, UI/UX, Research, Presentation), view potential teammates, compare skills/interests, Team Compatibility Score, send/accept invitations.
- **FR-14**: Transparent mock compatibility scores labeled as frontend demo, not real AI.

### Mentor Portal
- **FR-15**: Mentor directory with search and expertise filters; mentor profiles with details, qualifications, experience, availability, interests; Request Mentorship action with demo status.

### Interaction
- **FR-16**: All buttons/links work; sidebar nav with active states; search/filters; form validation; join/leave; event registration; team creation/matching; profile editing; notifications; responsive mobile nav.
- **FR-17**: Persist demo data with localStorage. Do not claim real emails/notifications/AI/auth.

### Code Quality
- **FR-18**: Reusable components: Navbar, Sidebar, StatCard, CommunityCard, EventCard, MentorCard, RegistrationForm, TeamMatchCard, Modal, EmptyState. React Router, separate pages, clean CSS, consistent naming.

## Non-Functional Requirements
- **NFR-1**: Responsive across desktop, tablet, mobile.
- **NFR-2**: Clean, readable typography, consistent spacing, attractive empty states.
- **NFR-3**: Avoid clutter and excessive animations.
- **NFR-4**: Eventra branding prominent.
- **NFR-5**: No console errors.

## Constraints
- **Technical**: React + Vite + JS + React Router + Lucide React. Custom CSS or CSS modules.
- **Business**: Mock data + localStorage only; API-ready for future backend.
- **Dependencies**: npm packages (react, react-dom, react-router-dom, lucide-react, vite).

## Assumptions
- Demo registration creates a user in localStorage; "login" uses the same stored data.
- AI team formation uses mock compatibility scores based on skill/interest overlap.
- A single demo user role is active at a time (stored in localStorage).

## Acceptance Criteria

### AC-1: Landing page renders branding and role cards
- **Type**: `rule`
- **Given**: User opens the app root URL
- **When**: Landing page loads
- **Then**: "Welcome to Eventra" heading, tagline, description, and 3 role cards (Member, Mentor, Participant) with icons and CTA buttons are visible
- **Pass Condition**: All elements present and role card buttons open registration form
- **Evidence**: Visual check + no console errors

### AC-2: Role-based registration forms with validation
- **Type**: `rule`
- **Given**: User clicks a role card CTA
- **When**: Registration form renders
- **Then**: Role-specific fields appear; required-field validation shows error messages; submit shows loading then success; data persisted in localStorage
- **Pass Condition**: All role forms validate, show feedback, persist to localStorage
- **Evidence**: Form submit test across all 3 roles

### AC-3: Login form authenticates against stored demo user
- **Type**: `rule`
- **Given**: A demo user exists in localStorage
- **When**: User submits login with matching email/password
- **Then**: User is redirected to dashboard; wrong credentials show error
- **Pass Condition**: Login succeeds for stored user, fails otherwise
- **Evidence**: Login flow test

### AC-4: Dashboard with sidebar navigation and stats
- **Type**: `rule`
- **Given**: User is logged in
- **When**: Dashboard loads
- **Then**: Sidebar with all listed sections, top nav, stat cards, upcoming events, communities, recent activities, quick actions render; active nav state works
- **Pass Condition**: All sidebar sections present and navigable; stats display
- **Evidence**: Dashboard renders with all sections

### AC-5: Communities list with search/filter and join/leave
- **Type**: `rule`
- **Given**: User on All Communities page
- **When**: Searching/filtering and clicking Join/Leave
- **Then**: Cards filter correctly; Join adds to My Communities and prevents duplicate; Leave removes
- **Pass Condition**: Search/filter works; join/leave persists to localStorage
- **Evidence**: Community interaction test

### AC-6: Community details page
- **Type**: `rule`
- **Given**: User clicks a community card
- **When**: Details page loads
- **Then**: Full description, mission, rules, tech, members, events, Join/Leave button render
- **Pass Condition**: All details sections present; action works
- **Evidence**: Details page renders

### AC-7: Events with category filters and registration
- **Type**: `rule`
- **Given**: User on Events page
- **When**: Filtering by category, viewing details, registering
- **Then**: Events filter by category; details page shows full info; Register updates My Registrations; prevents duplicate registration
- **Pass Condition**: Filters work; registration persists; My Registrations shows them
- **Evidence**: Events interaction test

### AC-8: AI team formation with compatibility scores
- **Type**: `rule`
- **Given**: User on AI Team Formation page
- **When**: Creating a team, selecting roles, viewing matches
- **Then**: Team creation persists; potential teammates listed; compatibility score shown (labeled demo); send/accept invitations works
- **Pass Condition**: All team formation interactions work with demo scores
- **Evidence**: Team formation flow test

### AC-9: Mentor directory and mentorship request
- **Type**: `rule`
- **Given**: User on Mentors page
- **When**: Searching/filtering mentors, requesting mentorship
- **Then**: Mentor cards filter; details page shows full profile; Request action sets demo status
- **Pass Condition**: Mentor search/filter works; request status persists
- **Evidence**: Mentor interaction test

### AC-10: Responsive design and no console errors
- **Type**: `rubric`
- **Dimension**: Responsive layout & runtime quality
- **Scale**: 1-5
- **Anchors**: 1 = broken layout, console errors; 3 = usable on desktop only, minor errors; 5 = fully responsive desktop/tablet/mobile, zero console errors
- **Pass Threshold**: >= 4
- **Evidence**: Browser check at 3 breakpoints; console clean

### AC-11: Reusable component architecture
- **Type**: `rubric`
- **Dimension**: Code structure & reusability
- **Scale**: 1-5
- **Anchors**: 1 = single-file app, no components; 3 = some components, inconsistent naming; 5 = clean components/ (Navbar, Sidebar, StatCard, CommunityCard, EventCard, MentorCard, RegistrationForm, TeamMatchCard, Modal, EmptyState), pages/, layouts/, data/, context/, hooks/, styles/, consistent naming
- **Pass Threshold**: >= 4
- **Evidence**: File structure inspection

### AC-12: Premium SaaS visual design
- **Type**: `rubric`
- **Dimension**: Visual design quality
- **Scale**: 1-5
- **Anchors**: 1 = unstyled; 3 = basic styling; 5 = deep navy/violet/lavender palette, rounded cards, subtle shadows, gradients, smooth hovers, consistent spacing, empty states
- **Pass Threshold**: >= 4
- **Evidence**: Visual inspection

## Open Questions
- None; requirements are explicit and detailed.
